
import React, { createContext, useState, useEffect, useCallback, ReactNode, useContext } from 'react';
import { Notification, NotificationContextType, NotificationType } from '../types';
import * as notificationService from '../services/notificationService';
import { useAuth } from './AuthContext';

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const { user } = useAuth();

  const fetchNotifications = useCallback(async () => {
    if (!user) {
        setNotifications([]);
        setUnreadCount(0);
        return;
    };
    try {
      const userNotifications = await notificationService.getNotifications(user.id);
      setNotifications(userNotifications);
      setUnreadCount(userNotifications.filter(n => !n.isRead).length);
    } catch (error) {
      console.error("Failed to fetch notifications", error);
    }
  }, [user]);

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000); // Poll for new notifications
    return () => clearInterval(interval);
  }, [fetchNotifications]);

  const markAsRead = useCallback(async (notificationIds: string[]) => {
    if (!user || notificationIds.length === 0) return;
    await notificationService.markNotificationsAsRead(user.id, notificationIds);
    // Optimistic update
    setNotifications(prev =>
      prev.map(n => (notificationIds.includes(n.id) ? { ...n, isRead: true } : n))
    );
    setUnreadCount(prev => Math.max(0, prev - notificationIds.length));
  }, [user]);

  const createNotification = useCallback(async (
      recipientId: string,
      text: string,
      type: NotificationType,
      relatedItemId?: string
    ) => {
      await notificationService.createNotification(recipientId, text, type, relatedItemId);
      if (user && recipientId === user.id) {
          fetchNotifications(); // Re-fetch if the current user is the recipient
      }
  }, [user, fetchNotifications]);


  const value = {
    notifications,
    unreadCount,
    fetchNotifications,
    markAsRead,
    createNotification,
  };

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
};

export const useNotifications = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
