
import { Notification, NotificationType } from '../types';

const NOTIFICATIONS_KEY = 'exchange_app_notifications';

const getStoredNotifications = (): Notification[] => {
  const notificationsJson = localStorage.getItem(NOTIFICATIONS_KEY);
  return notificationsJson ? JSON.parse(notificationsJson) : [];
};

const saveNotifications = (notifications: Notification[]) => {
  localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
};

export const getNotifications = (userId: string): Promise<Notification[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const allNotifications = getStoredNotifications();
      const userNotifications = allNotifications
        .filter(n => n.userId === userId)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      resolve(userNotifications);
    }, 200);
  });
};

export const createNotification = (
    recipientId: string, 
    text: string, 
    type: NotificationType, 
    relatedItemId?: string
): Promise<Notification> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allNotifications = getStoredNotifications();
            const newNotification: Notification = {
                id: `notif_${Date.now()}`,
                userId: recipientId,
                text,
                type,
                relatedItemId,
                isRead: false,
                createdAt: new Date().toISOString(),
            };
            allNotifications.push(newNotification);
            saveNotifications(allNotifications);
            resolve(newNotification);
        }, 100);
    });
};

export const markNotificationsAsRead = (userId: string, notificationIds: string[]): Promise<void> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            let allNotifications = getStoredNotifications();
            allNotifications = allNotifications.map(n => {
                if (n.userId === userId && notificationIds.includes(n.id)) {
                    return { ...n, isRead: true };
                }
                return n;
            });
            saveNotifications(allNotifications);
            resolve();
        }, 100);
    });
};
