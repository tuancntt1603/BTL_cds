
import { Item, User } from '../types';

const ITEMS_KEY = 'exchange_app_items';
const RECENTLY_VIEWED_KEY = 'exchange_app_recently_viewed';
const FAVORITES_KEY_PREFIX = 'exchange_app_favorites_';
const MAX_RECENTLY_VIEWED = 4;

const initialItems: Item[] = [
  {
    id: 'item_1',
    title: 'Ghế Sofa Cũ',
    description: 'Ghế sofa êm ái, màu xám tro, còn khá mới. Phù hợp cho phòng khách nhỏ. Có vài vết xước nhỏ ở chân ghế nhưng không đáng kể.',
    imageUrl: 'https://picsum.photos/seed/sofa/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 21.0285, lon: 105.8542, name: 'Hà Nội' },
  },
  {
    id: 'item_2',
    title: 'Đàn Guitar Acoustic',
    description: 'Đàn guitar Taylor, âm thanh vang và ấm. Dây đàn mới thay. Tặng kèm bao đàn và bộ chỉnh dây. Thích hợp cho người mới bắt đầu.',
    imageUrl: 'https://picsum.photos/seed/guitar/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 10.7769, lon: 106.7009, name: 'TP. Hồ Chí Minh' },
  },
   {
    id: 'item_3',
    title: 'Xe đạp địa hình',
    description: 'Xe đạp Asama, bánh 26 inch, 21 tốc độ. Đã qua sử dụng nhưng vẫn chạy tốt, phanh và bộ đề hoạt động trơn tru. Có vài vết trầy xước trên sườn.',
    imageUrl: 'https://picsum.photos/seed/bike/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 16.0544, lon: 108.2022, name: 'Đà Nẵng' },
  },
  {
    id: 'item_4',
    title: 'Bộ sưu tập sách văn học',
    description: 'Hơn 20 cuốn sách văn học kinh điển Việt Nam và thế giới. Giấy đã ngả vàng theo thời gian nhưng còn nguyên vẹn, không rách.',
    imageUrl: 'https://picsum.photos/seed/books/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 21.03, lon: 105.86, name: 'Hà Nội' },
  },
  {
    id: 'item_5',
    title: 'Tủ lạnh mini Aqua',
    description: 'Tủ lạnh mini 90L, hoạt động tốt, làm lạnh nhanh. Thích hợp cho sinh viên hoặc phòng trọ. Ít tốn điện.',
    imageUrl: 'https://picsum.photos/seed/fridge/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.78, lon: 106.71, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_6',
    title: 'Lò vi sóng Sharp',
    description: 'Lò vi sóng có chức năng nướng, dung tích 20L. Bảng điều khiển dễ sử dụng. Mới dùng được 1 năm.',
    imageUrl: 'https://picsum.photos/seed/microwave/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.01, lon: 105.84, name: 'Hà Nội' },
  },
  {
    id: 'item_7',
    title: 'Máy ảnh phim Canon',
    description: 'Máy ảnh phim cổ điển, hoạt động hoàn hảo. Lens sạch, không mốc. Tặng kèm 1 cuộn phim.',
    imageUrl: 'https://picsum.photos/seed/filmcamera/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 16.06, lon: 108.21, name: 'Đà Nẵng' },
  },
  {
    id: 'item_8',
    title: 'Tai nghe Sony WH-1000XM3',
    description: 'Tai nghe chống ồn chủ động đỉnh cao, chất âm tuyệt vời. Pin còn rất tốt. Fullbox.',
    imageUrl: 'https://picsum.photos/seed/headphones/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 10.80, lon: 106.69, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_9',
    title: 'Bàn phím cơ Filco',
    description: 'Bàn phím cơ Filco Majestouch 2, brown switch. Cảm giác gõ rất tốt. Đã vệ sinh sạch sẽ.',
    imageUrl: 'https://picsum.photos/seed/keyboard/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 21.04, lon: 105.83, name: 'Hà Nội' },
  },
  {
    id: 'item_10',
    title: 'Màn hình Dell Ultrasharp 24 inch',
    description: 'Màn hình Dell U2419H, độ phân giải Full HD, màu sắc chuẩn. Không có điểm chết. Còn bảo hành.',
    imageUrl: 'https://picsum.photos/seed/monitor/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 10.75, lon: 106.72, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_11',
    title: 'Loa Bluetooth JBL Charge 4',
    description: 'Loa di động chống nước, pin trâu, âm bass mạnh mẽ. Ít sử dụng nên còn rất mới.',
    imageUrl: 'https://picsum.photos/seed/speaker/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 16.07, lon: 108.22, name: 'Đà Nẵng' },
  },
  {
    id: 'item_12',
    title: 'Máy chơi game PS4 Slim',
    description: 'Máy PS4 Slim 500GB, hoạt động mượt mà. Kèm 2 tay cầm và 3 đĩa game.',
    imageUrl: 'https://picsum.photos/seed/ps4/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 21.00, lon: 105.85, name: 'Hà Nội' },
  },
  {
    id: 'item_13',
    title: 'Apple Watch Series 3',
    description: 'Đồng hồ thông minh Apple Watch S3 38mm, có vài vết xước dăm. Pin dùng ổn 1 ngày.',
    imageUrl: 'https://picsum.photos/seed/applewatch/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.79, lon: 106.68, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_14',
    title: 'Bàn làm việc gỗ sồi',
    description: 'Bàn làm việc chân sắt mặt gỗ sồi, kích thước 120x60cm. Chắc chắn, không mối mọt.',
    imageUrl: 'https://picsum.photos/seed/desk/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.02, lon: 105.82, name: 'Hà Nội' },
  },
  {
    id: 'item_15',
    title: 'Ghế công thái học',
    description: 'Ghế xoay văn phòng, có tựa đầu và kê tay. Lưng lưới thoáng mát. Piston hoạt động tốt.',
    imageUrl: 'https://picsum.photos/seed/ergohair/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.76, lon: 106.70, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_16',
    title: 'Kệ sách 5 tầng',
    description: 'Kệ sách gỗ công nghiệp, màu trắng, cao 1m8. Vẫn còn chắc chắn.',
    imageUrl: 'https://picsum.photos/seed/bookshelf/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 16.04, lon: 108.19, name: 'Đà Nẵng' },
  },
  {
    id: 'item_17',
    title: 'Tủ quần áo 2 cánh',
    description: 'Tủ nhựa, nhẹ, dễ di chuyển. Thích hợp cho người ở trọ. Không hỏng hóc.',
    imageUrl: 'https://picsum.photos/seed/wardrobe/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 21.05, lon: 105.81, name: 'Hà Nội' },
  },
  {
    id: 'item_18',
    title: 'Đèn cây trang trí',
    description: 'Đèn cây phong cách tối giản, thân kim loại, chao vải. Ánh sáng vàng ấm cúng.',
    imageUrl: 'https://picsum.photos/seed/floorlamp/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 10.81, lon: 106.66, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_19',
    title: 'Bộ truyện tranh Dragon Ball',
    description: 'Full bộ 42 cuốn truyện Dragon Ball tái bản. Giấy còn trắng, không rách.',
    imageUrl: 'https://picsum.photos/seed/dragonball/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.03, lon: 105.80, name: 'Hà Nội' },
  },
  {
    id: 'item_20',
    title: 'Sách "Nhà Giả Kim"',
    description: 'Cuốn sách nổi tiếng, còn rất mới, không gập gáy. Phù hợp làm quà tặng.',
    imageUrl: 'https://picsum.photos/seed/alchemist/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'new',
    location: { lat: 10.77, lon: 106.68, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_21',
    title: 'Đĩa than nhạc Trịnh Công Sơn',
    description: 'Đĩa than gốc, âm thanh mộc mạc, hoài niệm. Bìa đĩa hơi cũ theo thời gian.',
    imageUrl: 'https://picsum.photos/seed/vinyl/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 16.08, lon: 108.23, name: 'Đà Nẵng' },
  },
  {
    id: 'item_22',
    title: 'Bộ cờ vua gỗ',
    description: 'Bộ cờ vua bằng gỗ thông, quân cờ được điêu khắc tỉ mỉ. Bàn cờ có thể gập lại.',
    imageUrl: 'https://picsum.photos/seed/chess/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.06, lon: 105.79, name: 'Hà Nội' },
  },
  {
    id: 'item_23',
    title: 'Ván trượt longboard',
    description: 'Ván dài, phù hợp để dạo phố. Bánh xe còn tốt, mặt ván có vài vết xước.',
    imageUrl: 'https://picsum.photos/seed/longboard/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.82, lon: 106.65, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_24',
    title: 'Vợt cầu lông Yonex',
    description: 'Vợt còn tốt, lưới mới căng. Nhẹ, phù hợp cho người chơi phong trào.',
    imageUrl: 'https://picsum.photos/seed/badminton/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 16.03, lon: 108.18, name: 'Đà Nẵng' },
  },
  {
    id: 'item_25',
    title: 'Áo khoác da nam',
    description: 'Áo khoác da thật, size L. Kiểu dáng Biker. Da còn mềm, không nổ.',
    imageUrl: 'https://picsum.photos/seed/leatherjacket/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 20.99, lon: 105.84, name: 'Hà Nội' },
  },
  {
    id: 'item_26',
    title: 'Giày Nike Air Force 1',
    description: 'Giày AF1 trắng, size 42. Đế hơi mòn, da có vài vết nhăn. Đã vệ sinh sạch.',
    imageUrl: 'https://picsum.photos/seed/af1/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.74, lon: 106.67, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_27',
    title: 'Balo laptop The North Face',
    description: 'Balo chống nước, nhiều ngăn, có ngăn đựng laptop 15.6 inch. Khóa kéo tốt.',
    imageUrl: 'https://picsum.photos/seed/backpack/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 16.05, lon: 108.24, name: 'Đà Nẵng' },
  },
  {
    id: 'item_28',
    title: 'Mắt kính Ray-Ban Aviator',
    description: 'Kính phi công cổ điển, gọng vàng, tròng xanh rêu. Hàng chính hãng, có xước nhẹ.',
    imageUrl: 'https://picsum.photos/seed/rayban/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 21.04, lon: 105.85, name: 'Hà Nội' },
  },
  {
    id: 'item_29',
    title: 'Ví da bò thật',
    description: 'Ví da nam, nhiều ngăn đựng thẻ. Da đã lên màu patina đẹp.',
    imageUrl: 'https://picsum.photos/seed/wallet/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.83, lon: 106.64, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_30',
    title: 'Váy hoa vintage',
    description: 'Váy maxi hoa nhí, chất vải voan mát. Phù hợp đi biển, dạo phố. Freesize.',
    imageUrl: 'https://picsum.photos/seed/dress/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.03, lon: 105.82, name: 'Hà Nội' },
  },
  {
    id: 'item_31',
    title: 'Nón lưỡi trai Adidas',
    description: 'Nón màu đen, logo thêu. Ít đội nên còn mới.',
    imageUrl: 'https://picsum.photos/seed/cap/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 16.02, lon: 108.20, name: 'Đà Nẵng' },
  },
  {
    id: 'item_32',
    title: 'Máy xay sinh tố Philips',
    description: 'Máy xay đa năng, cối thủy tinh, xay đá tốt. Lưỡi dao còn sắc bén.',
    imageUrl: 'https://picsum.photos/seed/blender/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.72, lon: 106.69, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_33',
    title: 'Nồi chiên không dầu Lock&Lock',
    description: 'Dung tích 5L, phù hợp cho gia đình. Lớp chống dính còn tốt. Hoạt động ổn định.',
    imageUrl: 'https://picsum.photos/seed/airfryer/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 20.98, lon: 105.80, name: 'Hà Nội' },
  },
  {
    id: 'item_34',
    title: 'Bộ dao bếp 6 món',
    description: 'Bộ dao Đức, thép không gỉ, kèm giá đỡ gỗ. Dao còn rất bén.',
    imageUrl: 'https://picsum.photos/seed/knifeset/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 10.84, lon: 106.63, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_35',
    title: 'Lều cắm trại 2 người',
    description: 'Lều chống mưa tốt, dễ dựng. Đã dùng 2 lần đi cắm trại. Không rách.',
    imageUrl: 'https://picsum.photos/seed/tent/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 16.01, lon: 108.21, name: 'Đà Nẵng' },
  },
  {
    id: 'item_36',
    title: 'Vali du lịch size M',
    description: 'Vali nhựa ABS, bánh xe xoay 360 độ. Có vài vết xước bên ngoài, bên trong còn mới.',
    imageUrl: 'https://picsum.photos/seed/suitcase/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 21.07, lon: 105.78, name: 'Hà Nội' },
  },
  {
    id: 'item_37',
    title: 'Máy hút bụi cầm tay',
    description: 'Máy hút bụi Xiaomi, lực hút mạnh, pin dùng khoảng 30 phút. Phù hợp hút bụi xe hơi, sofa.',
    imageUrl: 'https://picsum.photos/seed/vacuum/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 10.73, lon: 106.71, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_38',
    title: 'Bình giữ nhiệt Yeti',
    description: 'Bình giữ nóng lạnh tốt, dung tích 1L. Ít dùng, không móp méo.',
    imageUrl: 'https://picsum.photos/seed/tumbler/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.02, lon: 105.88, name: 'Hà Nội' },
  },
  {
    id: 'item_39',
    title: 'Dụng cụ tập yoga',
    description: 'Bao gồm 1 thảm, 2 gạch tập. Thảm có vài vết bẩn nhỏ nhưng đã vệ sinh.',
    imageUrl: 'https://picsum.photos/seed/yoga/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.85, lon: 106.62, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_40',
    title: 'Quạt cây Midea',
    description: 'Quạt 5 cánh, chạy êm, gió mát. Có điều khiển từ xa.',
    imageUrl: 'https://picsum.photos/seed/fan/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 16.00, lon: 108.22, name: 'Đà Nẵng' },
  },
  {
    id: 'item_41',
    title: 'Tranh sơn dầu phong cảnh',
    description: 'Tranh vẽ tay, kích thước 60x90cm. Màu sắc tươi sáng, phù hợp treo phòng khách.',
    imageUrl: 'https://picsum.photos/seed/painting/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.08, lon: 105.77, name: 'Hà Nội' },
  },
  {
    id: 'item_42',
    title: 'Đàn Ukulele soprano',
    description: 'Đàn nhỏ xinh, âm thanh vui tai. Thích hợp cho người mới học. Tặng kèm bao vải.',
    imageUrl: 'https://picsum.photos/seed/ukulele/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.71, lon: 106.73, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_43',
    title: 'Gương soi toàn thân',
    description: 'Gương có khung gỗ, kích thước 40x160cm. Gương trong, không ố.',
    imageUrl: 'https://picsum.photos/seed/mirror/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.01, lon: 105.89, name: 'Hà Nội' },
  },
  {
    id: 'item_44',
    title: 'Thảm trải sàn phòng khách',
    description: 'Thảm lông xù màu xám, kích thước 1.6x2m. Đã giặt sạch sẽ.',
    imageUrl: 'https://picsum.photos/seed/rug/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.86, lon: 106.61, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_45',
    title: 'Bộ bàn ăn 4 ghế',
    description: 'Bộ bàn ăn gỗ cao su, mặt bàn có vài vết xước. Ghế còn chắc chắn.',
    imageUrl: 'https://picsum.photos/seed/diningtable/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 15.99, lon: 108.23, name: 'Đà Nẵng' },
  },
  {
    id: 'item_46',
    title: 'Đồng hồ Casio G-Shock',
    description: 'Mẫu GA-110, chống sốc, chống nước. Hoạt động tốt mọi chức năng. Dây có trầy.',
    imageUrl: 'https://picsum.photos/seed/gshock/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 21.09, lon: 105.76, name: 'Hà Nội' },
  },
  {
    id: 'item_47',
    title: 'Túi xách nữ da thật',
    description: 'Túi da màu nâu, kích thước vừa phải, đựng được nhiều đồ. Lớp lót sạch sẽ.',
    imageUrl: 'https://picsum.photos/seed/handbag/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 10.70, lon: 106.74, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_48',
    title: 'Máy tính bảng Samsung Tab S6 Lite',
    description: 'Máy kèm bút Spen, màn hình 10.4 inch. Phù hợp ghi chú, giải trí. Còn mới, không trầy.',
    imageUrl: 'https://picsum.photos/seed/tabs6/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 16.06, lon: 108.17, name: 'Đà Nẵng' },
  },
  {
    id: 'item_49',
    title: 'Giường ngủ 1m6x2m',
    description: 'Giường gỗ công nghiệp, có ngăn kéo ở dưới. Dát giường còn chắc.',
    imageUrl: 'https://picsum.photos/seed/bed/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 20.97, lon: 105.81, name: 'Hà Nội' },
  },
  {
    id: 'item_50',
    title: 'Bàn trà sofa',
    description: 'Bàn trà mặt kính, chân kim loại. Kiểu dáng hiện đại. Mặt kính có vài vết xước nhỏ.',
    imageUrl: 'https://picsum.photos/seed/coffeetable/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.87, lon: 106.60, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_51',
    title: 'Mô hình Gundam (đã lắp)',
    description: 'Mô hình MG Freedom Gundam 2.0. Đã lắp ráp, không dán decal. Đầy đủ phụ kiện.',
    imageUrl: 'https://picsum.photos/seed/gundam/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 21.04, lon: 105.89, name: 'Hà Nội' },
  },
  {
    id: 'item_52',
    title: 'Bộ bài ma sói',
    description: 'Bộ Ma Sói Ultimate, đầy đủ các lá bài chức năng. Hộp hơi cũ nhưng bài còn mới.',
    imageUrl: 'https://picsum.photos/seed/werewolf/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'used',
    location: { lat: 10.69, lon: 106.75, name: 'TP. Hồ Chí Minh' },
  },
  {
    id: 'item_53',
    title: 'Cà vạt lụa',
    description: 'Cà vạt lụa tơ tằm, màu xanh navy, họa tiết chấm bi. Thích hợp cho môi trường công sở.',
    imageUrl: 'https://picsum.photos/seed/tie/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'new',
    location: { lat: 16.07, lon: 108.16, name: 'Đà Nẵng' },
  },
  {
    id: 'item_54',
    title: 'Hộp đựng đồ đa năng',
    description: 'Bộ 3 hộp vải đựng đồ, có thể gấp gọn. Giúp tủ quần áo ngăn nắp hơn.',
    imageUrl: 'https://picsum.photos/seed/storagebox/600/400',
    ownerId: 'user_0',
    ownerName: 'Người dùng Demo',
    condition: 'like-new',
    location: { lat: 20.96, lon: 105.82, name: 'Hà Nội' },
  },
];


const initializeItems = () => {
  const itemsJson = localStorage.getItem(ITEMS_KEY);
  if (!itemsJson) {
    localStorage.setItem(ITEMS_KEY, JSON.stringify(initialItems));
  }
};

initializeItems();

const getStoredItems = (): Item[] => {
  const itemsJson = localStorage.getItem(ITEMS_KEY);
  return itemsJson ? JSON.parse(itemsJson) : [];
};

export const getItems = (): Promise<Item[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getStoredItems().reverse());
    }, 300);
  });
};

export const getItemById = (id: string): Promise<Item | undefined> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const item = getStoredItems().find(i => i.id === id);
            resolve(item);
        }, 200);
    });
};

export const getItemsByOwner = (ownerId: string): Promise<Item[]> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allItems = getStoredItems();
            resolve(allItems.filter(item => item.ownerId === ownerId).reverse());
        }, 300);
    });
};

export const addItem = (itemData: Omit<Item, 'id' | 'ownerId' | 'ownerName'>, owner: User): Promise<Item> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allItems = getStoredItems();
            const newItem: Item = {
                ...itemData,
                id: `item_${Date.now()}`,
                ownerId: owner.id,
                ownerName: owner.name
            };
            allItems.push(newItem);
            localStorage.setItem(ITEMS_KEY, JSON.stringify(allItems));
            resolve(newItem);
        }, 500);
    });
};

export const updateItem = (itemId: string, updatedData: Partial<Omit<Item, 'id' | 'ownerId' | 'ownerName'>>, ownerId: string): Promise<Item> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            let allItems = getStoredItems();
            const itemIndex = allItems.findIndex(i => i.id === itemId);

            if (itemIndex === -1) {
                return reject(new Error("Không tìm thấy đồ vật."));
            }

            if (allItems[itemIndex].ownerId !== ownerId) {
                return reject(new Error("Bạn không có quyền chỉnh sửa đồ vật này."));
            }
            
            const updatedItem = { ...allItems[itemIndex], ...updatedData };
            allItems[itemIndex] = updatedItem;
            
            localStorage.setItem(ITEMS_KEY, JSON.stringify(allItems));
            resolve(updatedItem);
        }, 500);
    });
};

export const deleteItem = (itemId: string, ownerId: string): Promise<void> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            let allItems = getStoredItems();
            const itemIndex = allItems.findIndex(i => i.id === itemId);

            if (itemIndex === -1) {
                return reject(new Error("Không tìm thấy đồ vật."));
            }

            if (allItems[itemIndex].ownerId !== ownerId) {
                return reject(new Error("Bạn không có quyền xóa đồ vật này."));
            }

            allItems.splice(itemIndex, 1);
            localStorage.setItem(ITEMS_KEY, JSON.stringify(allItems));
            resolve();
        }, 500);
    });
};


// Recently Viewed Items
export const addRecentlyViewedItem = (itemId: string): void => {
    const recentlyViewedJson = localStorage.getItem(RECENTLY_VIEWED_KEY);
    let recentlyViewed: string[] = recentlyViewedJson ? JSON.parse(recentlyViewedJson) : [];
    recentlyViewed = recentlyViewed.filter(id => id !== itemId);
    recentlyViewed.unshift(itemId);
    const trimmedList = recentlyViewed.slice(0, MAX_RECENTLY_VIEWED);
    localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(trimmedList));
};

export const getRecentlyViewedItems = (): Promise<Item[]> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const recentlyViewedJson = localStorage.getItem(RECENTLY_VIEWED_KEY);
            const recentlyViewedIds: string[] = recentlyViewedJson ? JSON.parse(recentlyViewedJson) : [];
            if (recentlyViewedIds.length === 0) {
                resolve([]);
                return;
            }
            const allItems = getStoredItems();
            const recentlyViewedItems = recentlyViewedIds
                .map(id => allItems.find(item => item.id === id))
                .filter((item): item is Item => !!item);
            resolve(recentlyViewedItems);
        }, 100);
    });
};

// Favorite Items
export const getFavoriteItemIds = (userId: string): string[] => {
    const favoritesJson = localStorage.getItem(`${FAVORITES_KEY_PREFIX}${userId}`);
    return favoritesJson ? JSON.parse(favoritesJson) : [];
};

const saveFavoriteItemIds = (userId: string, itemIds: string[]): void => {
    localStorage.setItem(`${FAVORITES_KEY_PREFIX}${userId}`, JSON.stringify(itemIds));
};

export const toggleFavoriteStatus = (userId: string, itemId: string): string[] => {
    let favoriteIds = getFavoriteItemIds(userId);
    const isFavorite = favoriteIds.includes(itemId);

    if (isFavorite) {
        favoriteIds = favoriteIds.filter(id => id !== itemId);
    } else {
        favoriteIds.push(itemId);
    }
    
    saveFavoriteItemIds(userId, favoriteIds);
    return favoriteIds;
};

export const getFavoriteItems = (userId: string): Promise<Item[]> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const favoriteIds = getFavoriteItemIds(userId);
            if (favoriteIds.length === 0) {
                resolve([]);
                return;
            }
            const allItems = getStoredItems();
            const favoriteItems = favoriteIds
                .map(id => allItems.find(item => item.id === id))
                .filter((item): item is Item => !!item)
                .reverse(); // Show most recently favorited first
            resolve(favoriteItems);
        }, 100);
    });
};
