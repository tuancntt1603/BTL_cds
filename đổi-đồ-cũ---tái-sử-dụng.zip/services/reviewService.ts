import { Review, User } from '../types';
import * as authService from './authService';

const REVIEWS_KEY = 'exchange_app_reviews';

const getStoredReviews = (): Review[] => {
  const reviewsJson = localStorage.getItem(REVIEWS_KEY);
  return reviewsJson ? JSON.parse(reviewsJson) : [];
};

const saveReviews = (reviews: Review[]) => {
  localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews));
};

export const getReviewsForUser = (userId: string): Promise<Review[]> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allReviews = getStoredReviews();
            const userReviews = allReviews
                .filter(r => r.reviewedUserId === userId)
                .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            resolve(userReviews);
        }, 200);
    });
};

export const addReview = (
    reviewData: Omit<Review, 'id' | 'createdAt'>,
    reviewer: User
): Promise<Review> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const allReviews = getStoredReviews();
            
            // Prevent self-review and multiple reviews for the same item from the same user
            if (reviewData.reviewedUserId === reviewer.id) {
                return reject(new Error("Bạn không thể tự đánh giá chính mình."));
            }
            const existingReview = allReviews.find(r => r.itemId === reviewData.itemId && r.reviewerId === reviewer.id);
            if (existingReview) {
                return reject(new Error("Bạn đã đánh giá cho lần trao đổi này rồi."));
            }

            const newReview: Review = {
                ...reviewData,
                id: `review_${Date.now()}`,
                reviewerId: reviewer.id,
                reviewerName: reviewer.name,
                createdAt: new Date().toISOString(),
            };
            allReviews.push(newReview);
            saveReviews(allReviews);

            // Update reviewed user's reputation
            const usersJson = localStorage.getItem('exchange_app_users');
            const users: User[] = usersJson ? JSON.parse(usersJson) : [];
            const reviewedUser = users.find(u => u.id === reviewData.reviewedUserId);

            if (reviewedUser) {
                let reputationChange = 0;
                switch (reviewData.rating) {
                    case 5: reputationChange = 15; break;
                    case 4: reputationChange = 10; break;
                    case 3: reputationChange = 2; break;
                    case 2: reputationChange = -5; break;
                    case 1: reputationChange = -10; break;
                }
                const newReputation = (reviewedUser.reputation || 0) + reputationChange;
                authService.updateUserById(reviewData.reviewedUserId, { reputation: newReputation });
            }

            resolve(newReview);
        }, 300);
    });
};