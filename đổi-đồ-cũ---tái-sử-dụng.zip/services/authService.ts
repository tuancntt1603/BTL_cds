import { User } from '../types';

const USERS_KEY = 'exchange_app_users';
const CURRENT_USER_KEY = 'exchange_app_current_user';

const getStoredUsers = (): User[] => {
  const usersJson = localStorage.getItem(USERS_KEY);
  return usersJson ? JSON.parse(usersJson) : [];
};

const saveStoredUsers = (users: User[]): void => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export const login = (email: string, password: string): Promise<User> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const users = getStoredUsers();
      const user = users.find(u => u.email === email); // Note: Password check is omitted for this mock
      if (user) {
        localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
        resolve(user);
      } else {
        reject(new Error('Email hoặc mật khẩu không hợp lệ'));
      }
    }, 500);
  });
};

export const register = (name: string, email: string, password: string): Promise<User> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const users = getStoredUsers();
      if (users.some(u => u.email === email)) {
        reject(new Error('Email đã tồn tại'));
        return;
      }
      const newUser: User = {
        id: `user_${Date.now()}`,
        name,
        email,
        reputation: 0,
      };
      users.push(newUser);
      saveStoredUsers(users);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));
      resolve(newUser);
    }, 500);
  });
};

export const logout = (): void => {
  localStorage.removeItem(CURRENT_USER_KEY);
};

export const getCurrentUser = (): User | null => {
  const userJson = localStorage.getItem(CURRENT_USER_KEY);
  return userJson ? JSON.parse(userJson) : null;
};

export const getUsers = (): Promise<User[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getStoredUsers());
    }, 100);
  });
};

export const updateUserById = (userId: string, updatedData: Partial<User>): User | null => {
    const users = getStoredUsers();
    let updatedUser: User | null = null;
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex !== -1) {
        users[userIndex] = { ...users[userIndex], ...updatedData };
        updatedUser = users[userIndex];
        saveStoredUsers(users);

        // If the updated user is the current user, update their session too
        const currentUser = getCurrentUser();
        if (currentUser && currentUser.id === userId) {
            localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updatedUser));
        }
    }
    return updatedUser;
}

export const updateCurrentUser = (updatedData: Partial<User>): User | null => {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    return updateUserById(currentUser.id, updatedData);
}