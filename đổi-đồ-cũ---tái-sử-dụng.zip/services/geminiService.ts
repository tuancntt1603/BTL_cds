

import { GoogleGenAI } from "@google/genai";
import { Item } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API Key for Gemini is not set. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const generateDescription = async (
  title: string,
  keywords: string,
  condition: string,
  imageBase64: string,
  imageMimeType: string
): Promise<string> => {
  if (!API_KEY) {
    return Promise.reject(new Error("API Key không được định cấu hình."));
  }

  try {
    const model = 'gemini-2.5-flash';
    const imagePart = {
      inlineData: {
        mimeType: imageMimeType,
        data: imageBase64,
      },
    };

    const textPart = {
      text: `Hãy đóng vai một người bán hàng online chuyên nghiệp. Dựa vào hình ảnh và các thông tin sau, hãy viết một đoạn mô tả sản phẩm đồ cũ thật hấp dẫn, trung thực và thân thiện bằng tiếng Việt.
      - Tên sản phẩm: ${title}
      - Tình trạng: ${condition}
      - Từ khóa mô tả thêm: ${keywords}
      
      Yêu cầu:
      - Đoạn văn nên ngắn gọn, khoảng 3-5 câu.
      - Nhấn mạnh vào công dụng, ưu điểm hoặc vẻ ngoài của sản phẩm.
      - Giọng văn thân thiện, mời gọi, khuyến khích tái sử dụng.
      - Không thêm các thông tin không có trong hình hoặc mô tả (ví dụ: giá cả, thông tin liên hệ).`
    };
    
    const response = await ai.models.generateContent({
      model: model,
      contents: { parts: [imagePart, textPart] },
    });

    return response.text;
  } catch (error) {
    console.error("Lỗi khi gọi Gemini API:", error);
    throw new Error("Không thể tạo mô tả bằng AI. Vui lòng thử lại.");
  }
};


export const chatWithAI = async (query: string, items: Item[]): Promise<string> => {
    if (!API_KEY) {
        return Promise.reject(new Error("API Key không được định cấu hình."));
    }

    try {
        const model = 'gemini-2.5-flash';
        const itemsJson = JSON.stringify(items.map(i => ({ id: i.id, title: i.title, description: i.description, condition: i.condition })));

        const prompt = `Bạn là một trợ lý AI hữu ích cho một nền tảng trao đổi đồ cũ. Mục tiêu của bạn là giúp người dùng tìm thấy các món đồ dựa trên yêu cầu của họ. Tôi sẽ cung cấp cho bạn một truy vấn của người dùng và danh sách các mặt hàng có sẵn ở định dạng JSON.

Truy vấn của người dùng: "${query}"

Các mặt hàng có sẵn: ${itemsJson}

Hãy phân tích truy vấn của người dùng và tìm các mặt hàng phù hợp nhất từ danh sách. Trả lời bằng tiếng Việt.

Phản hồi của bạn phải là một tin nhắn thân thiện, theo sau là danh sách các mặt hàng phù hợp. Đối với mỗi mặt hàng phù hợp, hãy cung cấp tiêu đề và ID của nó ở định dạng "- [item_id] Tiêu đề sản phẩm".

Ví dụ định dạng phản hồi:
"Chào bạn, mình tìm thấy một vài món đồ phù hợp với yêu cầu của bạn nè:
- [item_1] Ghế Sofa Cũ
- [item_3] Xe đạp địa hình"

Nếu bạn không thể tìm thấy bất kỳ mặt hàng phù hợp nào, hãy trả lời bằng một thông báo thân thiện. Ví dụ: "Rất tiếc, mình không tìm thấy món đồ nào phù hợp. Bạn thử tìm với từ khoá khác xem sao nhé!"`;
        
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
        });

        return response.text;
    } catch (error) {
        console.error("Lỗi khi gọi Gemini API cho chatbot:", error);
        throw new Error("Trợ lý AI đang gặp sự cố. Vui lòng thử lại sau.");
    }
};

export const generateKeywordsFromImage = async (
  imageBase64: string,
  imageMimeType: string
): Promise<string> => {
  if (!API_KEY) {
    return Promise.reject(new Error("API Key không được định cấu hình."));
  }

  try {
    const model = 'gemini-2.5-flash';
    const imagePart = {
      inlineData: {
        mimeType: imageMimeType,
        data: imageBase64,
      },
    };

    const textPart = {
      text: `Phân tích hình ảnh của món đồ cũ này. Đưa ra 3-5 từ khóa (tags) ngắn gọn, phù hợp bằng tiếng Việt để mô tả nó. Các từ khóa nên cách nhau bởi dấu phẩy.
      Ví dụ: bàn gỗ, cổ điển, phòng khách
      Chỉ trả về các từ khóa, không thêm bất kỳ lời giải thích nào khác.`
    };
    
    const response = await ai.models.generateContent({
      model: model,
      contents: { parts: [imagePart, textPart] },
    });

    return response.text;
  } catch (error) {
    console.error("Lỗi khi tạo từ khóa bằng AI:", error);
    // Trả về chuỗi rỗng để không làm gián đoạn người dùng nếu có lỗi
    return ""; 
  }
};

export const generateImage = async (prompt: string): Promise<string> => {
    if (!API_KEY) {
        return Promise.reject(new Error("API Key không được định cấu hình."));
    }
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: `Một bức ảnh chân thực, chuyên nghiệp chụp một món đồ cũ được mô tả như sau: "${prompt}". Nền trắng, ánh sáng đẹp.`,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/jpeg',
              aspectRatio: '4:3',
            },
        });
        
        if (response.generatedImages && response.generatedImages.length > 0) {
            return response.generatedImages[0].image.imageBytes;
        } else {
            throw new Error("AI không thể tạo ra hình ảnh.");
        }

    } catch(error) {
        console.error("Lỗi khi tạo ảnh bằng AI:", error);
        throw new Error("Không thể tạo ảnh bằng AI. Vui lòng thử lại.");
    }
};

export const getListingSuggestions = async (
    title: string,
    description: string,
    imageBase64: string,
    imageMimeType: string
): Promise<string> => {
    if (!API_KEY) {
        return Promise.reject(new Error("API Key không được định cấu hình."));
    }
    
    try {
        const model = 'gemini-2.5-flash';
        const imagePart = {
          inlineData: {
            mimeType: imageMimeType,
            data: imageBase64,
          },
        };

        const textPart = {
          text: `Bạn là một chuyên gia marketing cho nền tảng trao đổi đồ cũ. Hãy phân tích tin đăng sau và đưa ra các gợi ý cụ thể để làm nó hấp dẫn hơn. Trả lời bằng tiếng Việt, định dạng HTML.
          - Tiêu đề: ${title}
          - Mô tả: ${description}
          - Hình ảnh: (đính kèm)

          Yêu cầu:
          - Đưa ra 2-3 gợi ý chính, tập trung vào việc cải thiện tiêu đề, mô tả và hình ảnh.
          - Mỗi gợi ý phải có tiêu đề in đậm (dùng thẻ <strong>) và giải thích ngắn gọn, dễ hiểu.
          - Giọng văn thân thiện, mang tính xây dựng.
          Ví dụ:
          "<strong>Thêm chi tiết vào tiêu đề:</strong> Hãy thử 'Ghế sofa êm ái màu xám tro, còn khá mới' để người xem hình dung rõ hơn.<br>"
          "<strong>Mô tả câu chuyện món đồ:</strong> Bạn có thể kể thêm lý do đổi hoặc một kỷ niệm nhỏ để kết nối hơn với người mua."
          `
        };
        
        const response = await ai.models.generateContent({
          model: model,
          contents: { parts: [imagePart, textPart] },
        });

        return response.text;
    } catch (error) {
        console.error("Lỗi khi tạo gợi ý tin đăng:", error);
        throw new Error("Không thể tạo gợi ý. Vui lòng thử lại.");
    }
};

export const suggestSimilarItems = async (currentItem: Item, allItems: Item[]): Promise<string[]> => {
    if (!API_KEY) {
        return Promise.reject(new Error("API Key không được định cấu hình."));
    }

    try {
        const model = 'gemini-2.5-flash';
        // Lọc bỏ món đồ hiện tại khỏi danh sách
        const otherItems = allItems.filter(i => i.id !== currentItem.id);
        const itemsJson = JSON.stringify(otherItems.map(i => ({ id: i.id, title: i.title, description: i.description })));
        const currentItemJson = JSON.stringify({ title: currentItem.title, description: currentItem.description });

        const prompt = `Bạn là một trợ lý gợi ý sản phẩm. Dựa vào món đồ người dùng đang xem và danh sách các món đồ khác, hãy tìm ra 3 món đồ tương tự hoặc liên quan nhất.

Món đồ đang xem: ${currentItemJson}

Danh sách các món đồ khác: ${itemsJson}

Chỉ trả về ID của các món đồ được gợi ý, mỗi ID trên một dòng, không có gì khác.
Ví dụ:
item_3
item_10
item_15
`;
        
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
        });

        const suggestedIds = response.text.split('\n').map(id => id.trim()).filter(Boolean);
        return suggestedIds;
    } catch (error) {
        console.error("Lỗi khi gợi ý món đồ tương tự:", error);
        return []; // Trả về mảng rỗng nếu có lỗi
    }
};