import { Report, ReportReason } from '../types';

const REPORTS_KEY = 'exchange_app_reports';

const getStoredReports = (): Report[] => {
  const reportsJson = localStorage.getItem(REPORTS_KEY);
  return reportsJson ? JSON.parse(reportsJson) : [];
};

const saveReports = (reports: Report[]): void => {
  localStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
};

export const addReport = (
  itemId: string,
  reporterId: string,
  reason: ReportReason,
  comment: string
): Promise<Report> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const allReports = getStoredReports();

      const existingReport = allReports.find(
        r => r.itemId === itemId && r.reporterId === reporterId
      );

      if (existingReport) {
        return reject(new Error('Bạn đã báo cáo mặt hàng này rồi.'));
      }

      const newReport: Report = {
        id: `report_${Date.now()}`,
        itemId,
        reporterId,
        reason,
        comment,
        createdAt: new Date().toISOString(),
      };

      allReports.push(newReport);
      saveReports(allReports);
      resolve(newReport);
    }, 300);
  });
};

export const getReportedItemIdsByUser = (userId: string): Promise<Set<string>> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allReports = getStoredReports();
            const reportedIds = new Set(
                allReports
                    .filter(r => r.reporterId === userId)
                    .map(r => r.itemId)
            );
            resolve(reportedIds);
        }, 100);
    });
};
