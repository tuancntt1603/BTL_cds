import React from 'react';
import { Item } from '../../types';
import Button from '../ui/Button';
import { useAuth } from '../../context/AuthContext';

interface ItemCardProps {
  item: Item;
  onViewDetails: (itemId: string) => void;
  isFavorite: boolean;
  onToggleFavorite: (itemId: string) => void;
  isReported: boolean;
  onReport: (item: Item) => void;
  onEdit?: (itemId: string) => void;
  onDelete?: (itemId: string) => void;
  onSuggest?: (item: Item) => void; // New prop for AI suggestions
}

const HeartIcon: React.FC<React.SVGProps<SVGSVGElement> & { isFavorite: boolean }> = ({ isFavorite, ...props }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={isFavorite ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.5l1.318-1.182a4.5 4.5 0 116.364 6.364L12 20.25l-7.682-7.682a4.5 4.5 0 010-6.364z" />
  </svg>
);

const FlagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" {...props}>
        <path fillRule="evenodd" d="M3 6a3 3 0 013-3h10a1 1 0 01.8 1.6L14.25 8l2.55 3.4A1 1 0 0116 13H6a1 1 0 00-1 1v3a1 1 0 11-2 0V6z" clipRule="evenodd" />
    </svg>
);

const LocationIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
  </svg>
);

const AiIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m12.728 0l.707-.707M6.343 17.657l-.707.707m12.728 0l.707.707M12 21v-1m-4-4H5a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2zM19 13h-2a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2z" />
    </svg>
);


const ItemCard: React.FC<ItemCardProps> = ({ item, onViewDetails, isFavorite, onToggleFavorite, isReported, onReport, onEdit, onDelete, onSuggest }) => {
  const { isAuthenticated } = useAuth();
  
  const conditionMap = {
    'new': { text: 'Mới', color: 'bg-blue-100 text-blue-800' },
    'like-new': { text: 'Như mới', color: 'bg-green-100 text-green-800' },
    'used': { text: 'Đã dùng', color: 'bg-yellow-100 text-yellow-800' },
    'for-parts': { text: 'Hỏng/Linh kiện', color: 'bg-red-100 text-red-800' }
  };
  
  const conditionInfo = conditionMap[item.condition] || conditionMap['used'];

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isAuthenticated) {
        onToggleFavorite(item.id);
    } else {
        alert("Vui lòng đăng nhập để sử dụng tính năng này.");
    }
  };
  
  const handleReportClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isAuthenticated && !isReported) {
        onReport(item);
    } else if (!isAuthenticated) {
        alert("Vui lòng đăng nhập để sử dụng tính năng này.");
    }
  };


  return (
    <div 
      className="bg-base-100 rounded-lg shadow-lg overflow-hidden flex flex-col transition-transform duration-300 hover:scale-105 hover:shadow-xl"
    >
      <div className="relative">
        <img 
            src={item.imageUrl} 
            alt={item.title} 
            className="w-full h-48 object-cover cursor-pointer" 
            onClick={() => onViewDetails(item.id)}
        />
        {isAuthenticated && (
            <>
                <button
                    onClick={handleFavoriteClick}
                    className={`absolute top-2 right-2 p-1.5 rounded-full transition-colors duration-200 ${
                        isFavorite ? 'text-red-500 bg-white/70' : 'text-white bg-black/40 hover:bg-black/60'
                    }`}
                    aria-label={isFavorite ? 'Bỏ yêu thích' : 'Yêu thích'}
                >
                    <HeartIcon isFavorite={isFavorite} />
                </button>
                <button
                    onClick={handleReportClick}
                    disabled={isReported}
                    className={`absolute top-2 left-2 p-1.5 rounded-full transition-colors duration-200 ${
                        isReported 
                            ? 'text-red-500 bg-white/70 cursor-not-allowed' 
                            : 'text-white bg-black/40 hover:bg-black/60'
                    }`}
                    aria-label={isReported ? 'Đã báo cáo' : 'Báo cáo'}
                    title={isReported ? 'Bạn đã báo cáo tin này' : 'Báo cáo tin này'}
                >
                    <FlagIcon />
                </button>
            </>
        )}
      </div>
      <div 
        className="p-4 flex flex-col flex-grow cursor-pointer"
        onClick={() => onViewDetails(item.id)}
      >
        <div className="flex justify-between items-start mb-2">
            <h3 className="text-lg font-bold text-neutral truncate pr-2">{item.title}</h3>
            <span className={`text-xs font-semibold px-2 py-1 rounded-full ${conditionInfo.color}`}>
                {conditionInfo.text}
            </span>
        </div>
        <p className="text-gray-600 text-sm mb-4 flex-grow">{item.description.substring(0, 100)}{item.description.length > 100 ? '...' : ''}</p>
        <div className="mt-auto border-t pt-3">
          <div className="flex justify-between items-center text-xs text-gray-500 mb-2">
            <div className="flex items-center min-w-0">
                <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-xs font-semibold text-gray-600 mr-2 flex-shrink-0">
                    {item.ownerName.charAt(0)}
                </div>
                <span className="truncate">
                    <span className="hidden sm:inline">Đăng bởi: </span>
                    <span className="font-semibold text-neutral">{item.ownerName}</span>
                </span>
            </div>
             {item.location && (
                <div className="flex items-center gap-1 flex-shrink-0 ml-2">
                    <LocationIcon />
                    <span className="truncate">{item.location.name}</span>
                </div>
            )}
          </div>
          <Button 
            className="w-full" 
            variant="secondary"
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(item.id);
            }}
          >
            Xem chi tiết
          </Button>
          {(onEdit || onDelete || onSuggest) && (
            <div className="flex gap-2 mt-2">
              {onSuggest && (
                 <Button size="sm" variant="ghost" className="w-full text-secondary hover:bg-orange-100" onClick={(e) => { e.stopPropagation(); onSuggest(item); }}>
                    <AiIcon/> Gợi ý
                 </Button>
              )}
              {onEdit && <Button size="sm" variant="ghost" className="w-full" onClick={(e) => { e.stopPropagation(); onEdit(item.id); }}>Sửa</Button>}
              {onDelete && <Button size="sm" variant="ghost" className="w-full text-red-600 hover:bg-red-100" onClick={(e) => { e.stopPropagation(); onDelete(item.id); }}>Xóa</Button>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ItemCard;