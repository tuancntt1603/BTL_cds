import React, { useState } from 'react';
import { Item, ReportReason } from '../../types';
import { useAuth } from '../../context/AuthContext';
import * as reportService from '../../services/reportService';
import Modal from '../ui/Modal';
import Button from '../ui/Button';

interface ReportItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: Item | null;
  onReportSuccess: (itemId: string) => void;
}

const ReportItemModal: React.FC<ReportItemModalProps> = ({ isOpen, onClose, item, onReportSuccess }) => {
  const [reason, setReason] = useState<ReportReason | ''>('');
  const [comment, setComment] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !item) {
      setError('Bạn cần đăng nhập để thực hiện hành động này.');
      return;
    }
    if (!reason) {
      setError('Vui lòng chọn lý do báo cáo.');
      return;
    }

    setError('');
    setIsLoading(true);

    try {
      await reportService.addReport(item.id, user.id, reason, comment);
      onReportSuccess(item.id);
      onClose();
      // Reset form for next time
      setReason('');
      setComment('');
    } catch (err: any) {
      setError(err.message || 'Không thể gửi báo cáo. Vui lòng thử lại.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!item) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Báo cáo "${item.title}"`}>
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <p className="text-red-500 bg-red-100 p-3 rounded-md">{error}</p>}
        <div>
          <label htmlFor="reason" className="block text-sm font-medium text-gray-700 mb-1">Lý do *</label>
          <select
            id="reason"
            value={reason}
            onChange={(e) => setReason(e.target.value as ReportReason)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
          >
            <option value="" disabled>-- Chọn lý do --</option>
            <option value="spam">Spam hoặc quảng cáo</option>
            <option value="inappropriate">Nội dung không phù hợp</option>
            <option value="scam">Lừa đảo hoặc gây hiểu lầm</option>
            <option value="prohibited">Mặt hàng bị cấm</option>
          </select>
        </div>
        <div>
          <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-1">Chi tiết thêm (tùy chọn)</label>
          <textarea
            id="comment"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
            placeholder="Cung cấp thêm thông tin nếu cần..."
          />
        </div>
        <div className="flex items-center justify-end gap-4 pt-2">
          <Button type="button" variant="ghost" onClick={onClose} disabled={isLoading}>
            Hủy
          </Button>
          <Button type="submit" isLoading={isLoading}>
            Gửi báo cáo
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default ReportItemModal;
