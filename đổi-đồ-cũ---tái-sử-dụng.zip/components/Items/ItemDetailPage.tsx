import React, { useState, useEffect, useCallback } from 'react';
import { Item, View, Review } from '../../types';
import * as itemService from '../../services/itemService';
import * as reviewService from '../../services/reviewService';
import * as reportService from '../../services/reportService';
import Spinner from '../ui/Spinner';
import Button from '../ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import ReviewList from '../Reviews/ReviewList';
import ReviewForm from '../Reviews/ReviewForm';
import ContactSellerForm from './ContactSellerForm';
import ReportItemModal from './ReportItemModal';

interface ItemDetailPageProps {
  itemId: string;
  onNavigate: (view: View) => void;
}

const HeartIcon: React.FC<React.SVGProps<SVGSVGElement> & { isFavorite: boolean }> = ({ isFavorite, ...props }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={isFavorite ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 016.364 0L12 7.5l1.318-1.182a4.5 4.5 0 116.364 6.364L12 20.25l-7.682-7.682a4.5 4.5 0 010-6.364z" />
  </svg>
);

const LocationIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
  </svg>
);

const ShareIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12s-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.368a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
    </svg>
);


const ItemDetailPage: React.FC<ItemDetailPageProps> = ({ itemId, onNavigate }) => {
  const [item, setItem] = useState<Item | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const { user, isAuthenticated } = useAuth();
  const { createNotification } = useNotifications();
  const [notificationSent, setNotificationSent] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [isContacting, setIsContacting] = useState(false);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [hasReported, setHasReported] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const fetchItemAndReviews = useCallback(async () => {
    setIsLoading(true);
    setError('');
    try {
      const fetchedItem = await itemService.getItemById(itemId);
      if (fetchedItem) {
        setItem(fetchedItem);
        itemService.addRecentlyViewedItem(itemId);
        const fetchedReviews = await reviewService.getReviewsForUser(fetchedItem.ownerId);
        setReviews(fetchedReviews);
        if (user) {
            const [favIds, reportedIds] = await Promise.all([
                itemService.getFavoriteItemIds(user.id),
                reportService.getReportedItemIdsByUser(user.id)
            ]);
            setIsFavorite(favIds.includes(itemId));
            setHasReported(reportedIds.has(itemId));
        }
      } else {
        setError('Không tìm thấy đồ vật này.');
      }
    } catch (err) {
      setError('Lỗi khi tải thông tin chi tiết.');
    } finally {
      setIsLoading(false);
    }
  }, [itemId, user]);

  useEffect(() => {
    fetchItemAndReviews();
  }, [itemId, user]);

  const handleSendMessage = async (message: string) => {
    if (!user) {
        alert("Vui lòng đăng nhập để liên hệ với người đăng.");
        onNavigate({ page: 'login' });
        return;
    }
    if (user.id === item?.ownerId) {
        alert("Đây là đồ vật của bạn.");
        return;
    }
    
    if (item && !notificationSent) {
        setIsSendingMessage(true);
        try {
            const notificationText = `${user.name} đã gửi tin nhắn về món đồ "${item.title}": "${message}"`;
            await createNotification(
                item.ownerId,
                notificationText,
                'exchange_request',
                item.id
            );
            setNotificationSent(true);
            setIsContacting(false); 
            alert(`Đã gửi tin nhắn cho ${item.ownerName}!`);
        } catch (error) {
            console.error("Gửi tin nhắn thất bại:", error);
            alert("Gửi tin nhắn thất bại. Vui lòng thử lại.");
        } finally {
            setIsSendingMessage(false);
        }
    }
  };
  
  const handleReviewSubmitted = () => {
      setShowReviewForm(false);
      fetchItemAndReviews();
  }
  
  const handleToggleFavorite = () => {
      if (!user) {
          alert("Vui lòng đăng nhập để yêu thích sản phẩm.");
          return;
      }
      itemService.toggleFavoriteStatus(user.id, itemId);
      setIsFavorite(prev => !prev);
  }
  
  const handleShare = async () => {
    if (!item) return;

    const shareData = {
        title: `Đổi đồ: ${item.title}`,
        text: `Xem món đồ "${item.title}" trên ứng dụng Đổi Đồ!`,
        url: window.location.href, // Trong ứng dụng thực tế, đây sẽ là một deep link
    };

    if (navigator.share) {
        try {
            await navigator.share(shareData);
        } catch (error) {
            console.error('Lỗi khi chia sẻ:', error);
        }
    } else {
        // Fallback cho trình duyệt không hỗ trợ Web Share API
        navigator.clipboard.writeText(shareData.url).then(() => {
            setLinkCopied(true);
            setTimeout(() => setLinkCopied(false), 2000); // Ẩn thông báo sau 2 giây
        }).catch(err => {
            console.error('Không thể sao chép liên kết:', err);
            alert('Không thể sao chép liên kết.');
        });
    }
  };

  const handleReportSuccess = (reportedItemId: string) => {
    if (reportedItemId === itemId) {
        setHasReported(true);
    }
    alert("Cảm ơn bạn đã báo cáo. Chúng tôi sẽ xem xét sớm.");
  };

  const conditionMap = {
    'new': { text: 'Mới', color: 'bg-blue-100 text-blue-800' },
    'like-new': { text: 'Như mới', color: 'bg-green-100 text-green-800' },
    'used': { text: 'Đã dùng', color: 'bg-yellow-100 text-yellow-800' },
    'for-parts': { text: 'Hỏng/Linh kiện', color: 'bg-red-100 text-red-800' }
  };
  const conditionInfo = item ? conditionMap[item.condition] : null;

  if (isLoading) {
    return <Spinner />;
  }

  if (error) {
    return (
      <div className="text-center">
        <p className="text-red-500 text-lg">{error}</p>
        <Button onClick={() => onNavigate({ page: 'home' })} className="mt-4">
          Quay về trang chủ
        </Button>
      </div>
    );
  }

  if (!item) {
    return null; 
  }
  
  const canReview = user && user.id !== item.ownerId;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-base-100 p-6 md:p-8 rounded-2xl shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <img src={item.imageUrl} alt={item.title} className="w-full h-auto object-cover rounded-lg shadow-md" />
          </div>
          <div>
            <div className="flex justify-between items-start mb-3">
              <h1 className="text-3xl font-bold text-neutral">{item.title}</h1>
              {conditionInfo && (
                <span className={`text-sm font-semibold px-3 py-1 rounded-full ${conditionInfo.color}`}>
                  {conditionInfo.text}
                </span>
              )}
            </div>
            <div className="border-t pt-4 mb-4 space-y-2 text-sm">
               <p className="text-gray-500">Đăng bởi: <span className="font-semibold text-neutral">{item.ownerName}</span></p>
               {item.location && (
                 <div className="flex items-center text-gray-500 gap-2">
                    <LocationIcon />
                    <span className="font-semibold text-neutral">{item.location.name}</span>
                 </div>
               )}
            </div>
            <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{item.description}</p>
            
            <div className="mt-8">
                <div className="flex flex-col sm:flex-row gap-2">
                    {user && user.id !== item.ownerId && (
                        <>
                            <Button 
                                variant="secondary" 
                                className="w-full" 
                                onClick={() => setIsContacting(!isContacting)} 
                                disabled={notificationSent}
                            >
                                {notificationSent ? 'Yêu cầu đã được gửi' : (isContacting ? 'Đóng form' : 'Liên hệ với người bán')}
                            </Button>
                             <Button
                                variant="ghost"
                                className={`px-4 ${isFavorite ? 'text-red-500' : 'text-gray-600'}`}
                                onClick={handleToggleFavorite}
                                title={isFavorite ? 'Bỏ yêu thích' : 'Yêu thích'}
                            >
                                <HeartIcon isFavorite={isFavorite} />
                            </Button>
                             <Button
                                variant="ghost"
                                className="px-4 text-gray-600"
                                onClick={handleShare}
                                title="Chia sẻ"
                            >
                                <ShareIcon />
                            </Button>
                        </>
                    )}
                    {(!user || user.id === item.ownerId) && (
                         <Button variant="ghost" onClick={() => onNavigate({ page: 'home' })} className="w-full">
                            Xem các món khác
                        </Button>
                    )}
                </div>
                {linkCopied && <p className="text-sm text-green-600 text-center mt-2">Đã sao chép liên kết!</p>}

                {!isAuthenticated && (
                    <div className="mt-4 text-center p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                       <p className="text-yellow-800">
                           Vui lòng <button onClick={() => onNavigate({ page: 'login' })} className="font-bold underline">đăng nhập</button> để liên hệ hoặc yêu thích sản phẩm.
                       </p>
                    </div>
                )}

                {isContacting && !notificationSent && user && (
                    <ContactSellerForm 
                        sellerName={item.ownerName}
                        onSendMessage={handleSendMessage}
                        onCancel={() => setIsContacting(false)}
                        isSending={isSendingMessage}
                    />
                )}
            </div>
            
            <div className="text-center text-sm mt-6">
                {user && user.id !== item.ownerId && (
                    <button
                        onClick={() => setIsReportModalOpen(true)}
                        disabled={hasReported}
                        className="text-gray-500 hover:text-red-600 hover:underline disabled:text-gray-400 disabled:cursor-not-allowed disabled:no-underline"
                    >
                        {hasReported ? 'Bạn đã báo cáo tin này' : 'Báo cáo tin đăng này'}
                    </button>
                )}
            </div>

          </div>
        </div>
      </div>
      
      <div className="bg-base-100 p-6 md:p-8 rounded-2xl shadow-xl">
        <h2 className="text-2xl font-bold text-neutral mb-4">Đánh giá về {item.ownerName}</h2>
        {canReview && !showReviewForm && (
            <div className="text-center my-6">
                <Button onClick={() => setShowReviewForm(true)}>Viết đánh giá của bạn</Button>
            </div>
        )}
        {showReviewForm && user && (
            <ReviewForm 
                itemId={item.id}
                reviewedUserId={item.ownerId}
                onSubmitSuccess={handleReviewSubmitted}
                onCancel={() => setShowReviewForm(false)}
            />
        )}
        <ReviewList reviews={reviews} />
      </div>

      <ReportItemModal 
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
          item={item}
          onReportSuccess={handleReportSuccess}
      />
    </div>
  );
};

export default ItemDetailPage;
