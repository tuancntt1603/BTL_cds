import React, { useState } from 'react';
import Button from '../ui/Button';

interface ContactSellerFormProps {
  sellerName: string;
  onSendMessage: (message: string) => void;
  onCancel: () => void;
  isSending: boolean;
}

const ContactSellerForm: React.FC<ContactSellerFormProps> = ({ sellerName, onSendMessage, onCancel, isSending }) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message.trim());
    }
  };

  return (
    <div className="mt-6 border-t pt-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-2">Gửi tin nhắn cho {sellerName}</h3>
      <form onSubmit={handleSubmit}>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={4}
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
          placeholder="Chào bạn, mình quan tâm đến món đồ này..."
          required
          disabled={isSending}
        />
        <div className="flex items-center justify-end gap-4 mt-4">
          <Button type="button" variant="ghost" onClick={onCancel} disabled={isSending}>
            Hủy
          </Button>
          <Button type="submit" isLoading={isSending} disabled={!message.trim()}>
            Gửi tin nhắn
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ContactSellerForm;
