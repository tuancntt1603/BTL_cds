

import React, { useState, ChangeEvent } from 'react';
import { useAuth } from '../../context/AuthContext';
import * as itemService from '../../services/itemService';
import * as geminiService from '../../services/geminiService';
import { View, Item, Location } from '../../types';
import Button from '../ui/Button';

interface AddItemPageProps {
  onNavigate: (view: View) => void;
}

const AddItemPage: React.FC<AddItemPageProps> = ({ onNavigate }) => {
  const { user, updateUser } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [keywords, setKeywords] = useState('');
  const [condition, setCondition] = useState<Item['condition']>('used');
  const [locationName, setLocationName] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string>('');
  
  const [isDescAiLoading, setIsDescAiLoading] = useState(false);
  const [isKeywordsAiLoading, setIsKeywordsAiLoading] = useState(false);
  const [isImageAiLoading, setIsImageAiLoading] = useState(false);
  const [suggestedKeywords, setSuggestedKeywords] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
    });
  }

  const handleImageChange = async (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);

      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);

      // Bắt đầu tạo từ khóa bằng AI
      setSuggestedKeywords([]);
      setIsKeywordsAiLoading(true);
      try {
        const b64 = await fileToBase64(file);
        setImageBase64(b64);
        const keywordsString = await geminiService.generateKeywordsFromImage(b64, file.type);
        if (keywordsString) {
          setSuggestedKeywords(keywordsString.split(',').map(k => k.trim()).filter(Boolean));
        }
      } catch (err) {
        console.error("Lỗi khi tạo từ khóa:", err);
      } finally {
        setIsKeywordsAiLoading(false);
      }
    }
  };

  const handleGenerateDescription = async () => {
    if (!imageBase64 || !title) {
      setError('Vui lòng chọn hình ảnh và nhập tên đồ vật để AI có thể tạo mô tả.');
      return;
    }
    setError('');
    setIsDescAiLoading(true);

    try {
        const generatedDesc = await geminiService.generateDescription(title, keywords, condition, imageBase64, imageFile?.type || 'image/jpeg');
        setDescription(generatedDesc);
    } catch (err: any) {
        setError(err.message || 'Lỗi tạo mô tả bằng AI.');
    } finally {
        setIsDescAiLoading(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!title && !description) {
      setError("Vui lòng nhập tên và/hoặc mô tả để AI tạo ảnh.");
      return;
    }
    setError('');
    setIsImageAiLoading(true);

    try {
        const prompt = `${title}. ${description}`;
        const generatedImageBase64 = await geminiService.generateImage(prompt);
        const imageUrl = `data:image/jpeg;base64,${generatedImageBase64}`;
        setImagePreview(imageUrl);
        setImageBase64(generatedImageBase64);
        // Clear file input as we are using a generated image
        const fileInput = document.getElementById('image') as HTMLInputElement;
        if (fileInput) {
            fileInput.value = '';
        }
        setImageFile(null);

    } catch (err: any) {
        setError(err.message || 'Lỗi tạo ảnh bằng AI.');
    } finally {
        setIsImageAiLoading(false);
    }
  };

  const handleAddKeyword = (keywordToAdd: string) => {
    const currentKeywords = keywords.toLowerCase().split(',').map(k => k.trim());
    if (currentKeywords.includes(keywordToAdd.toLowerCase())) {
      return; // Bỏ qua nếu từ khóa đã tồn tại
    }
    setKeywords(prev => prev.trim() ? `${prev}, ${keywordToAdd}` : keywordToAdd);
  };


  const getMockLocation = (name: string): Location => {
      // Simple mock for demo. In a real app, use a Geocoding API.
      const lowerCaseName = name.toLowerCase();
      if (lowerCaseName.includes('hà nội')) {
          return { lat: 21.0285 + (Math.random() - 0.5) * 0.1, lon: 105.8542 + (Math.random() - 0.5) * 0.1, name: name };
      }
      if (lowerCaseName.includes('hcm') || lowerCaseName.includes('hồ chí minh')) {
          return { lat: 10.7769 + (Math.random() - 0.5) * 0.1, lon: 106.7009 + (Math.random() - 0.5) * 0.1, name: name };
      }
       if (lowerCaseName.includes('đà nẵng')) {
          return { lat: 16.0544 + (Math.random() - 0.5) * 0.1, lon: 108.2022 + (Math.random() - 0.5) * 0.1, name: name };
      }
      // Default to a random location in Vietnam if not recognized
      return { lat: 16.0 + Math.random() * 5, lon: 106.0 + Math.random() * 2, name: name };
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !imagePreview) {
        setError("Vui lòng điền đầy đủ thông tin, bao gồm cả hình ảnh và đăng nhập.");
        return;
    }
    setError('');
    setIsSubmitting(true);
    
    const imageUrl = imagePreview; // Use the preview which can be from file or AI
    const location = locationName ? getMockLocation(locationName) : undefined;

    try {
        await itemService.addItem({ title, description, imageUrl, condition, location }, user);
        updateUser({ reputation: (user.reputation || 0) + 10 });
        onNavigate({ page: 'myItems' });
    } catch (err: any) {
        setError(err.message || 'Không thể đăng tin. Vui lòng thử lại.');
    } finally {
        setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-base-100 p-8 rounded-xl shadow-lg">
      <h2 className="text-3xl font-bold text-center text-primary mb-6">Đăng tin đồ vật mới</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && <p className="text-red-500 bg-red-100 p-3 rounded-md">{error}</p>}

        <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">Tên đồ vật *</label>
            <input id="title" type="text" value={title} onChange={e => setTitle(e.target.value)} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
        </div>

        <div>
            <label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-1">Hình ảnh *</label>
            <div className="flex items-center gap-4">
                 <input id="image" type="file" accept="image/*" onChange={handleImageChange} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary-content file:text-primary hover:file:bg-base-200"/>
            </div>
            {imagePreview && <img src={imagePreview} alt="Xem trước" className="mt-4 rounded-lg max-h-60 mx-auto" />}
        </div>
        
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="condition" className="block text-sm font-medium text-gray-700 mb-1">Tình trạng *</label>
                <select id="condition" value={condition} onChange={e => setCondition(e.target.value as Item['condition'])} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
                    <option value="used">Đã dùng</option>
                    <option value="like-new">Như mới</option>
                    <option value="new">Mới</option>
                    <option value="for-parts">Hỏng/Linh kiện</option>
                </select>
            </div>
             <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">Khu vực</label>
                <input id="location" type="text" value={locationName} onChange={e => setLocationName(e.target.value)} placeholder="Ví dụ: Hà Nội, TP.HCM" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
            </div>
        </div>


        <div className="p-4 bg-base-200 rounded-lg space-y-4">
             <h3 className="font-semibold text-lg text-neutral flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m12.728 0l.707-.707M6.343 17.657l-.707.707m12.728 0l.707.707M12 21v-1m-4-4H5a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2zM19 13h-2a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2z" /></svg>
                Tăng tốc với AI
            </h3>
            
            <div>
                <label htmlFor="keywords" className="block text-sm font-medium text-gray-700 mb-1">Từ khóa (ví dụ: "còn mới", "bằng gỗ", "cho bé",...)</label>
                <input id="keywords" type="text" value={keywords} onChange={e => setKeywords(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
                 <div className="mt-2 min-h-[28px]">
                    {isKeywordsAiLoading && (
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                            <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span>AI đang tìm gợi ý...</span>
                        </div>
                    )}
                    {suggestedKeywords.length > 0 && !isKeywordsAiLoading && (
                        <div className="flex flex-wrap gap-2 items-center">
                            <span className="text-sm text-gray-600 self-center">Gợi ý:</span>
                            {suggestedKeywords.map((keyword, index) => (
                                <button
                                    key={index}
                                    type="button"
                                    onClick={() => handleAddKeyword(keyword)}
                                    className="px-2 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full hover:bg-green-200 transition-colors"
                                >
                                    + {keyword}
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            </div>
            <div className="flex flex-wrap gap-2">
                 <Button type="button" variant="secondary" onClick={handleGenerateDescription} isLoading={isDescAiLoading} disabled={!imageBase64 || !title}>
                    {isDescAiLoading ? 'Đang nghĩ...' : 'Tạo mô tả bằng AI'}
                </Button>
                <Button type="button" variant="secondary" onClick={handleGenerateImage} isLoading={isImageAiLoading} disabled={!title && !description}>
                    {isImageAiLoading ? 'Đang tạo ảnh...' : 'Tạo ảnh demo với AI'}
                </Button>
            </div>
        </div>

        <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Mô tả chi tiết *</label>
            <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} required rows={5} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"></textarea>
        </div>

        <Button type="submit" isLoading={isSubmitting} className="w-full">
            {isSubmitting ? 'Đang đăng...' : 'Đăng tin'}
        </Button>
      </form>
    </div>
  );
};

export default AddItemPage;