import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import * as itemService from '../../services/itemService';
import { View, Item, Location } from '../../types';
import Button from '../ui/Button';
import Spinner from '../ui/Spinner';

interface EditItemPageProps {
  itemId: string;
  onNavigate: (view: View) => void;
}

const EditItemPage: React.FC<EditItemPageProps> = ({ itemId, onNavigate }) => {
  const { user } = useAuth();
  const [item, setItem] = useState<Item | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [condition, setCondition] = useState<Item['condition']>('used');
  const [locationName, setLocationName] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchItem = async () => {
      try {
        const fetchedItem = await itemService.getItemById(itemId);
        if (fetchedItem) {
          if (user && fetchedItem.ownerId !== user.id) {
            setError("Bạn không có quyền chỉnh sửa đồ vật này.");
            setIsLoading(false);
            return;
          }
          setItem(fetchedItem);
          setTitle(fetchedItem.title);
          setDescription(fetchedItem.description);
          setCondition(fetchedItem.condition);
          setLocationName(fetchedItem.location?.name || '');
          setImagePreview(fetchedItem.imageUrl);
        } else {
          setError("Không tìm thấy đồ vật.");
        }
      } catch (err) {
        setError("Lỗi khi tải dữ liệu.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchItem();
  }, [itemId, user]);

  const getMockLocation = (name: string): Location | undefined => {
      if (!name.trim()) return undefined;
      const lowerCaseName = name.toLowerCase();
      if (lowerCaseName.includes('hà nội')) {
          return { lat: 21.0285, lon: 105.8542, name: name };
      }
      if (lowerCaseName.includes('hcm') || lowerCaseName.includes('hồ chí minh')) {
          return { lat: 10.7769, lon: 106.7009, name: name };
      }
       if (lowerCaseName.includes('đà nẵng')) {
          return { lat: 16.0544, lon: 108.2022, name: name };
      }
      return { lat: 16.0, lon: 106.0, name: name };
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !item) {
        setError("Có lỗi xảy ra, vui lòng thử lại.");
        return;
    }
    setError('');
    setIsSubmitting(true);
    
    const location = getMockLocation(locationName);

    try {
        await itemService.updateItem(itemId, { title, description, condition, location }, user.id);
        alert("Cập nhật thành công!");
        onNavigate({ page: 'myItems' });
    } catch (err: any) {
        setError(err.message || 'Không thể cập nhật. Vui lòng thử lại.');
    } finally {
        setIsSubmitting(false);
    }
  };
  
  if (isLoading) return <Spinner />;

  if (error) {
    return (
        <div className="text-center">
            <p className="text-red-500 bg-red-100 p-3 rounded-md">{error}</p>
            <Button onClick={() => onNavigate({ page: 'myItems' })} className="mt-4">Quay lại Tin của tôi</Button>
        </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-base-100 p-8 rounded-xl shadow-lg">
      <h2 className="text-3xl font-bold text-center text-primary mb-6">Chỉnh sửa tin</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        
        <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">Tên đồ vật *</label>
            <input id="title" type="text" value={title} onChange={e => setTitle(e.target.value)} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
        </div>

        <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Hình ảnh</label>
            <p className="text-sm text-gray-500 mb-2">Tính năng thay đổi hình ảnh sẽ được cập nhật sớm.</p>
            {imagePreview && <img src={imagePreview} alt="Xem trước" className="mt-2 rounded-lg max-h-60 mx-auto" />}
        </div>
        
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="condition" className="block text-sm font-medium text-gray-700 mb-1">Tình trạng *</label>
                <select id="condition" value={condition} onChange={e => setCondition(e.target.value as Item['condition'])} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
                    <option value="used">Đã dùng</option>
                    <option value="like-new">Như mới</option>
                    <option value="new">Mới</option>
                    <option value="for-parts">Hỏng/Linh kiện</option>
                </select>
            </div>
             <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">Khu vực</label>
                <input id="location" type="text" value={locationName} onChange={e => setLocationName(e.target.value)} placeholder="Ví dụ: Hà Nội, TP.HCM" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" />
            </div>
        </div>

        <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Mô tả chi tiết *</label>
            <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} required rows={5} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"></textarea>
        </div>

        <div className="flex gap-4">
            <Button type="button" variant="ghost" onClick={() => onNavigate({ page: 'myItems' })} className="w-full">
                Hủy
            </Button>
            <Button type="submit" isLoading={isSubmitting} className="w-full">
                {isSubmitting ? 'Đang lưu...' : 'Lưu thay đổi'}
            </Button>
        </div>
      </form>
    </div>
  );
};

export default EditItemPage;