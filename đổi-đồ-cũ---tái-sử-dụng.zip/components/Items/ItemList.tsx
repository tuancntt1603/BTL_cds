import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Item, View, User } from '../../types';
import * as itemService from '../../services/itemService';
import * as authService from '../../services/authService';
import * as reportService from '../../services/reportService';
import ItemCard from './ItemCard';
import Spinner from '../ui/Spinner';
import Button from '../ui/Button';
import ReportItemModal from './ReportItemModal';
import MapView from './MapView';
import { useAuth } from '../../context/AuthContext';

interface ItemListProps {
  onNavigate: (view: View) => void;
}

type SortOption = 'newest' | 'popular' | 'nearest';
type ViewMode = 'list' | 'map';

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371; // Radius of the Earth in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in km
};

const ListIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
  </svg>
);

const MapIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13v-6m0-6l6-3m-6 3l6 3m0 0l5.447 2.724A1 1 0 0121 16.382V5.618a1 1 0 00-1.447-.894L15 7m-6 3v6m6-6v6" />
  </svg>
);

const ItemList: React.FC<ItemListProps> = ({ onNavigate }) => {
  const [items, setItems] = useState<Item[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<Item[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [reportedItemIds, setReportedItemIds] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('newest');
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [reportingItem, setReportingItem] = useState<Item | null>(null);
  const { user } = useAuth();
  const [userLocation, setUserLocation] = useState<{lat: number, lon: number} | null>(null);
  const [isLocating, setIsLocating] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [fetchedItems, fetchedUsers, fetchedRecentlyViewed] = await Promise.all([
            itemService.getItems(),
            authService.getUsers(),
            itemService.getRecentlyViewedItems()
        ]);
        setItems(fetchedItems);
        setUsers(fetchedUsers);
        setRecentlyViewed(fetchedRecentlyViewed);

        if (user) {
            const [favIds, repIds] = await Promise.all([
                itemService.getFavoriteItemIds(user.id),
                reportService.getReportedItemIdsByUser(user.id)
            ]);
            setFavoriteIds(new Set(favIds));
            setReportedItemIds(repIds);
        }

      } catch (error) {
        console.error("Lỗi khi tải dữ liệu:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [user]);
  
  const handleSortByNearest = () => {
    setSortOption('nearest');
    if (userLocation) return; // Already have location

    if (!navigator.geolocation) {
        alert("Trình duyệt của bạn không hỗ trợ định vị.");
        return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
        (position) => {
            setUserLocation({
                lat: position.coords.latitude,
                lon: position.coords.longitude,
            });
            setIsLocating(false);
        },
        (error) => {
            console.error("Lỗi định vị:", error);
            alert("Không thể lấy vị trí của bạn. Vui lòng cấp quyền truy cập vị trí.");
            setIsLocating(false);
            setSortOption('newest'); // Revert to default
        }
    );
  };


  const handleToggleFavorite = useCallback((itemId: string) => {
    if (!user) return;
    const newFavoriteIds = itemService.toggleFavoriteStatus(user.id, itemId);
    setFavoriteIds(new Set(newFavoriteIds));
  }, [user]);

  const handleViewDetails = (itemId: string) => {
    onNavigate({ page: 'itemDetail', itemId });
  };
  
  const handleOpenReportModal = (item: Item) => {
    if (!user) {
        alert("Vui lòng đăng nhập để báo cáo.");
        return;
    }
    setReportingItem(item);
  };

  const handleReportSuccess = (itemId: string) => {
    setReportedItemIds(prev => new Set(prev).add(itemId));
    alert("Cảm ơn bạn đã báo cáo. Chúng tôi sẽ xem xét sớm.");
  };

  const sortedAndFilteredItems = useMemo(() => {
    const filtered = items.filter(item => 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

    switch (sortOption) {
      case 'popular': {
        const userReputationMap = new Map(users.map(u => [u.id, u.reputation || 0]));
        return [...filtered].sort((a, b) => {
          const repA = userReputationMap.get(a.ownerId) || 0;
          const repB = userReputationMap.get(b.ownerId) || 0;
          return repB - repA;
        });
      }
      case 'nearest': {
        if (!userLocation) return filtered;
        const itemsWithLocation = filtered.filter(item => item.location);
        const itemsWithoutLocation = filtered.filter(item => !item.location);
        
        const sorted = itemsWithLocation.sort((a, b) => {
            const distA = calculateDistance(userLocation.lat, userLocation.lon, a.location!.lat, a.location!.lon);
            const distB = calculateDistance(userLocation.lat, userLocation.lon, b.location!.lat, b.location!.lon);
            return distA - distB;
        });

        return [...sorted, ...itemsWithoutLocation];
      }
      case 'newest':
      default:
        // Default API response is already sorted by newest
        return filtered;
    }
  }, [items, users, searchTerm, sortOption, userLocation]);

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div>
      {recentlyViewed.length > 0 && viewMode === 'list' && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-neutral">Bạn đã xem gần đây</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {recentlyViewed.map((item) => (
              <ItemCard 
                key={`recent-${item.id}`} 
                item={item} 
                onViewDetails={handleViewDetails} 
                isFavorite={favoriteIds.has(item.id)}
                onToggleFavorite={handleToggleFavorite}
                isReported={reportedItemIds.has(item.id)}
                onReport={handleOpenReportModal}
              />
            ))}
          </div>
        </div>
      )}

      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-2 text-neutral">Khám phá & Trao đổi</h1>
        <p className="text-lg text-gray-600">Tìm kiếm món đồ bạn cần, và cho đi những gì bạn không dùng nữa.</p>
      </div>

      <div className="mb-8 max-w-2xl mx-auto">
        <div className="relative">
          <input 
            type="text"
            placeholder="Tìm kiếm ghế sofa, sách, xe đạp..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-5 py-3 text-lg border-2 border-gray-300 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
          />
          <svg className="absolute right-4 top-1/2 -translate-y-1/2 h-6 w-6 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>
      
      <div className="flex justify-between items-center flex-wrap gap-4 mb-8">
        <div className="flex justify-center flex-wrap gap-2 md:gap-4 items-center">
            <span className="text-sm font-semibold text-gray-600 mr-2">Sắp xếp theo:</span>
            <Button size="sm" variant={sortOption === 'newest' ? 'primary' : 'ghost'} onClick={() => setSortOption('newest')}>Mới nhất</Button>
            <Button size="sm" variant={sortOption === 'popular' ? 'primary' : 'ghost'} onClick={() => setSortOption('popular')}>Phổ biến</Button>
            <Button size="sm" variant={sortOption === 'nearest' ? 'primary' : 'ghost'} onClick={handleSortByNearest} isLoading={isLocating}>
                {isLocating ? 'Đang tìm vị trí...' : 'Gần nhất'}
            </Button>
        </div>
        <div className="flex items-center gap-1 p-1 bg-base-200 rounded-lg">
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${viewMode === 'list' ? 'bg-white shadow text-primary' : 'text-gray-500 hover:bg-base-300'}`}
              aria-label="Chế độ xem danh sách"
              title="Chế độ xem danh sách"
            >
              <ListIcon />
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`p-2 rounded-md transition-colors ${viewMode === 'map' ? 'bg-white shadow text-primary' : 'text-gray-500 hover:bg-base-300'}`}
              aria-label="Chế độ xem bản đồ"
              title="Chế độ xem bản đồ"
            >
              <MapIcon />
            </button>
        </div>
      </div>

      {viewMode === 'list' ? (
        sortedAndFilteredItems.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {sortedAndFilteredItems.map((item) => (
              <ItemCard 
                  key={item.id} 
                  item={item} 
                  onViewDetails={handleViewDetails} 
                  isFavorite={favoriteIds.has(item.id)}
                  onToggleFavorite={handleToggleFavorite}
                  isReported={reportedItemIds.has(item.id)}
                  onReport={handleOpenReportModal}
              />
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 mt-10">
            {searchTerm ? `Không tìm thấy kết quả cho "${searchTerm}".` : "Chưa có đồ vật nào được đăng. Hãy là người đầu tiên!"}
          </p>
        )
      ) : (
        <MapView items={sortedAndFilteredItems} onNavigate={onNavigate} />
      )}


      <ReportItemModal 
          isOpen={!!reportingItem}
          onClose={() => setReportingItem(null)}
          item={reportingItem}
          onReportSuccess={handleReportSuccess}
      />
    </div>
  );
};

export default ItemList;