
import React, { useState, useEffect, useCallback } from 'react';
import { Item, View } from '../../types';
import * as itemService from '../../services/itemService';
import * as reportService from '../../services/reportService';
import { useAuth } from '../../context/AuthContext';
import ItemCard from './ItemCard';
import Spinner from '../ui/Spinner';
import Button from '../ui/Button';
import ReportItemModal from './ReportItemModal';

interface MyItemsPageProps {
  onNavigate: (view: View) => void;
}

const MyItemsPage: React.FC<MyItemsPageProps> = ({ onNavigate }) => {
  const [items, setItems] = useState<Item[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [reportedItemIds, setReportedItemIds] = useState<Set<string>>(new Set());
  const [reportingItem, setReportingItem] = useState<Item | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { user, updateUser } = useAuth();

  useEffect(() => {
    const fetchItems = async () => {
      if (!user) {
        setIsLoading(false);
        return;
      }
      setIsLoading(true);
      try {
        const [fetchedItems, favIds, repIds] = await Promise.all([
            itemService.getItemsByOwner(user.id),
            itemService.getFavoriteItemIds(user.id),
            reportService.getReportedItemIdsByUser(user.id)
        ]);
        setItems(fetchedItems);
        setFavoriteIds(new Set(favIds));
        setReportedItemIds(repIds);
      } catch (error) {
        console.error("Lỗi khi tải đồ vật của bạn:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchItems();
  }, [user]);
  
  const handleViewDetails = (itemId: string) => {
    onNavigate({ page: 'itemDetail', itemId });
  };

  const handleToggleFavorite = useCallback((itemId: string) => {
    if (!user) return;
    const newFavoriteIds = itemService.toggleFavoriteStatus(user.id, itemId);
    setFavoriteIds(new Set(newFavoriteIds));
  }, [user]);

  const handleOpenReportModal = (item: Item) => {
    if (!user) {
        alert("Vui lòng đăng nhập để báo cáo.");
        return;
    }
    setReportingItem(item);
  };

  const handleReportSuccess = (itemId: string) => {
    setReportedItemIds(prev => new Set(prev).add(itemId));
    alert("Cảm ơn bạn đã báo cáo. Chúng tôi sẽ xem xét sớm.");
  };

  const handleEditItem = (itemId: string) => {
    onNavigate({ page: 'editItem', itemId });
  };

  const handleDeleteItem = async (itemId: string) => {
    if (!user) return;
    if (window.confirm("Bạn có chắc chắn muốn xóa món đồ này không? Hành động này không thể hoàn tác.")) {
      try {
        await itemService.deleteItem(itemId, user.id);
        setItems(prevItems => prevItems.filter(item => item.id !== itemId));
        // Deduct reputation points for deleting
        const newReputation = Math.max(0, (user.reputation || 0) - 10);
        updateUser({ reputation: newReputation });
        alert("Đã xóa đồ vật thành công.");
      } catch (error: any) {
        console.error("Lỗi khi xóa đồ vật:", error);
        alert(`Lỗi: ${error.message}`);
      }
    }
  };

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div>
      <h1 className="text-4xl font-bold text-center mb-8 text-neutral">Tin của tôi</h1>
      {items.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {items.map((item) => (
            <ItemCard 
              key={item.id} 
              item={item} 
              onViewDetails={handleViewDetails}
              isFavorite={favoriteIds.has(item.id)}
              onToggleFavorite={handleToggleFavorite}
              isReported={reportedItemIds.has(item.id)}
              onReport={handleOpenReportModal}
              onEdit={handleEditItem}
              onDelete={handleDeleteItem}
            />
          ))}
        </div>
      ) : (
        <div className="text-center text-gray-500 mt-10 bg-base-100 p-8 rounded-lg shadow-sm max-w-lg mx-auto">
          <p className="text-lg mb-4">Bạn chưa đăng đồ vật nào.</p>
          <Button onClick={() => onNavigate({ page: 'addItem' })}>Bắt đầu đăng tin ngay</Button>
        </div>
      )}
      <ReportItemModal 
          isOpen={!!reportingItem}
          onClose={() => setReportingItem(null)}
          item={reportingItem}
          onReportSuccess={handleReportSuccess}
      />
    </div>
  );
};

export default MyItemsPage;