import React, { useEffect, useRef } from 'react';
import { Item, View } from '../../types';

// Khai báo L để TypeScript nhận diện vì nó được tải từ CDN
declare var L: any;

interface MapViewProps {
  items: Item[];
  onNavigate: (view: View) => void;
}

const MapView: React.FC<MapViewProps> = ({ items, onNavigate }) => {
  const mapRef = useRef<any>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const clusterGroupRef = useRef<any>(null);

  // Khởi tạo bản đồ
  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      const map = L.map(mapContainerRef.current).setView([16.0544, 108.2022], 6); // Trung tâm Việt Nam
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);
      mapRef.current = map;
    }
  }, []);

  // Cập nhật các ghim khi danh sách đồ vật thay đổi
  useEffect(() => {
    if (mapRef.current) {
      // Xóa cluster group cũ nếu tồn tại
      if (clusterGroupRef.current) {
        mapRef.current.removeLayer(clusterGroupRef.current);
      }
      
      const itemsWithLocation = items.filter(item => item.location);

      // Tạo một marker cluster group mới
      const markers = L.markerClusterGroup();
      clusterGroupRef.current = markers;


      // Thêm các ghim mới vào cluster group
      itemsWithLocation.forEach(item => {
        if (item.location) {
          const marker = L.marker([item.location.lat, item.location.lon]);
          
          // Thêm tiêu đề khi hover
          marker.bindTooltip(item.title);

          const popupContent = `
            <div class="w-48 leaflet-popup-content-wrapper">
              <img src="${item.imageUrl}" alt="${item.title}" class="w-full h-24 object-cover rounded-t-md cursor-pointer" onclick="document.getElementById('popup-nav-btn-${item.id}').click()" />
              <div class="p-2">
                <h4 class="font-bold text-sm truncate">${item.title}</h4>
                <p class="text-xs text-gray-500">${item.location.name}</p>
                <button id="popup-btn-${item.id}" class="w-full mt-2 text-xs bg-secondary text-white py-1 px-2 rounded hover:bg-secondary-focus">
                  Xem chi tiết
                </button>
              </div>
            </div>
            <a href="#" id="popup-nav-btn-${item.id}" style="display:none;"></a>
          `;

          marker.bindPopup(popupContent, { minWidth: 192, closeButton: false });

          // Gắn sự kiện sau khi popup mở ra
          marker.on('popupopen', () => {
            const btn = document.getElementById(`popup-btn-${item.id}`);
            const hiddenLink = document.getElementById(`popup-nav-btn-${item.id}`);
            
            const navigateToItem = () => onNavigate({ page: 'itemDetail', itemId: item.id });
            
            if (btn) {
              btn.onclick = navigateToItem;
            }
            if(hiddenLink){
                hiddenLink.onclick = (e) => {
                    e.preventDefault();
                    navigateToItem();
                }
            }
          });
          
          markers.addLayer(marker);
        }
      });
      
      // Thêm cluster group vào bản đồ
      mapRef.current.addLayer(markers);

      // Tự động điều chỉnh view để thấy tất cả các ghim
      if(itemsWithLocation.length > 0) {
          mapRef.current.fitBounds(markers.getBounds().pad(0.1));
      }
    }
  }, [items, onNavigate]);

  return <div ref={mapContainerRef} style={{ height: '600px', borderRadius: '12px' }} className="shadow-lg w-full z-10" />;
};

export default MapView;