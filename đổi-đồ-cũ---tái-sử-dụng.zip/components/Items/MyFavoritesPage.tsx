
import React, { useState, useEffect, useCallback } from 'react';
import { Item, View } from '../../types';
import * as itemService from '../../services/itemService';
import * as reportService from '../../services/reportService';
import { useAuth } from '../../context/AuthContext';
import ItemCard from './ItemCard';
import Spinner from '../ui/Spinner';
import Button from '../ui/Button';
import ReportItemModal from './ReportItemModal';

interface MyFavoritesPageProps {
  onNavigate: (view: View) => void;
}

const MyFavoritesPage: React.FC<MyFavoritesPageProps> = ({ onNavigate }) => {
  const [items, setItems] = useState<Item[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [reportedItemIds, setReportedItemIds] = useState<Set<string>>(new Set());
  const [reportingItem, setReportingItem] = useState<Item | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();

  const fetchFavoriteItems = useCallback(async () => {
    if (!user) {
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    try {
      const [fetchedItems, repIds] = await Promise.all([
        itemService.getFavoriteItems(user.id),
        reportService.getReportedItemIdsByUser(user.id)
      ]);
      setItems(fetchedItems);
      setFavoriteIds(new Set(fetchedItems.map(item => item.id)));
      setReportedItemIds(repIds);
    } catch (error) {
      console.error("Lỗi khi tải đồ vật yêu thích:", error);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchFavoriteItems();
  }, [fetchFavoriteItems]);
  
  const handleViewDetails = (itemId: string) => {
    onNavigate({ page: 'itemDetail', itemId });
  };
  
  const handleToggleFavorite = (itemId: string) => {
    if (!user) return;
    const newFavoriteIds = itemService.toggleFavoriteStatus(user.id, itemId);
    setFavoriteIds(new Set(newFavoriteIds));
    // Remove the item from the view immediately
    setItems(prevItems => prevItems.filter(item => item.id !== itemId));
  };

  const handleOpenReportModal = (item: Item) => {
    if (!user) {
        alert("Vui lòng đăng nhập để báo cáo.");
        return;
    }
    setReportingItem(item);
  };

  const handleReportSuccess = (itemId: string) => {
    setReportedItemIds(prev => new Set(prev).add(itemId));
    alert("Cảm ơn bạn đã báo cáo. Chúng tôi sẽ xem xét sớm.");
  };

  if (isLoading) {
    return <Spinner />;
  }

  return (
    <div>
      <h1 className="text-4xl font-bold text-center mb-8 text-neutral">Đồ vật yêu thích</h1>
      {items.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {items.map((item) => (
            // FIX: Pass isReported and onReport props to ItemCard to fix missing properties error.
            <ItemCard 
              key={item.id} 
              item={item} 
              onViewDetails={handleViewDetails}
              isFavorite={favoriteIds.has(item.id)}
              onToggleFavorite={handleToggleFavorite}
              isReported={reportedItemIds.has(item.id)}
              onReport={handleOpenReportModal}
            />
          ))}
        </div>
      ) : (
        <div className="text-center text-gray-500 mt-10 bg-base-100 p-8 rounded-lg shadow-sm max-w-lg mx-auto">
          <p className="text-lg mb-4">Bạn chưa có đồ vật yêu thích nào.</p>
          <Button onClick={() => onNavigate({ page: 'home' })}>Khám phá ngay</Button>
        </div>
      )}
      <ReportItemModal 
          isOpen={!!reportingItem}
          onClose={() => setReportingItem(null)}
          item={reportingItem}
          onReportSuccess={handleReportSuccess}
      />
    </div>
  );
};

export default MyFavoritesPage;
