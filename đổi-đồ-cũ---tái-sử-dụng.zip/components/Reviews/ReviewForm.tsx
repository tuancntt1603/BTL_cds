import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import * as reviewService from '../../services/reviewService';
import Button from '../ui/Button';
import StarRating from '../ui/StarRating';

interface ReviewFormProps {
    itemId: string;
    reviewedUserId: string;
    onSubmitSuccess: () => void;
    onCancel: () => void;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ itemId, reviewedUserId, onSubmitSuccess, onCancel }) => {
    const [rating, setRating] = useState(0);
    const [comment, setComment] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { user } = useAuth();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) {
            setError("Bạn cần đăng nhập để đánh giá.");
            return;
        }
        if (rating === 0) {
            setError("Vui lòng chọn số sao đánh giá.");
            return;
        }
        if (comment.trim() === '') {
            setError("Vui lòng viết nhận xét của bạn.");
            return;
        }
        
        setError('');
        setIsLoading(true);

        try {
            await reviewService.addReview({
                itemId,
                reviewedUserId,
                rating,
                comment,
                reviewerId: user.id, // Will be replaced in service, but good practice
                reviewerName: user.name,
            }, user);
            onSubmitSuccess();
        } catch (err: any) {
            setError(err.message || "Đã xảy ra lỗi khi gửi đánh giá.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="my-6 p-6 bg-gray-50 border border-gray-200 rounded-lg">
            <h3 className="text-lg font-semibold mb-4 text-gray-800">Chia sẻ trải nghiệm của bạn</h3>
             {error && <p className="text-red-500 bg-red-100 p-3 rounded-md mb-4">{error}</p>}
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Đánh giá của bạn *</label>
                    <StarRating rating={rating} onRatingChange={setRating} size="lg" />
                </div>
                <div>
                    <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-1">Nhận xét *</label>
                    <textarea 
                        id="comment"
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        rows={4}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                        placeholder="Trải nghiệm của bạn với người trao đổi này như thế nào?"
                    />
                </div>
                <div className="flex items-center justify-end gap-4">
                    <Button type="button" variant="ghost" onClick={onCancel}>Hủy</Button>
                    <Button type="submit" isLoading={isLoading}>Gửi đánh giá</Button>
                </div>
            </form>
        </div>
    );
};

export default ReviewForm;