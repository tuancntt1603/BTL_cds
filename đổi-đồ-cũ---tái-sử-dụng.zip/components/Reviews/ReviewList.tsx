import React from 'react';
import { Review } from '../../types';
import ReviewItem from './ReviewItem';

interface ReviewListProps {
    reviews: Review[];
}

const ReviewList: React.FC<ReviewListProps> = ({ reviews }) => {
    if (reviews.length === 0) {
        return (
            <div className="text-center py-8 px-4 bg-gray-50 rounded-lg">
                <p className="text-gray-500">Người dùng này chưa có đánh giá nào.</p>
            </div>
        );
    }
    
    return (
        <div className="space-y-4">
            {reviews.map(review => (
                <ReviewItem key={review.id} review={review} />
            ))}
        </div>
    );
};

export default ReviewList;