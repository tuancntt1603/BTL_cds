import React from 'react';
import { Review } from '../../types';
import StarRating from '../ui/StarRating';

interface ReviewItemProps {
    review: Review;
}

const ReviewItem: React.FC<ReviewItemProps> = ({ review }) => {
    return (
        <div className="py-4 border-b border-gray-200 last:border-b-0">
            <div className="flex items-start">
                <div className="flex-shrink-0 w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center font-bold text-gray-600">
                    {review.reviewerName.charAt(0)}
                </div>
                <div className="ml-4">
                    <div className="flex items-center gap-4">
                        <p className="font-semibold text-gray-800">{review.reviewerName}</p>
                        <StarRating rating={review.rating} readOnly={true} size="sm" />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                        {new Date(review.createdAt).toLocaleDateString('vi-VN', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric'
                        })}
                    </p>
                    <p className="text-gray-700 mt-2">{review.comment}</p>
                </div>
            </div>
        </div>
    );
};

export default ReviewItem;