
import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { View } from '../../types';
import Button from '../ui/Button';
import Notifications from '../Notifications/Notifications';

interface HeaderProps {
  onNavigate: (view: View) => void;
}

const RecycleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.37 6.26A9 9 0 106.26 18.37M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
  </svg>
);

const StarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" {...props}>
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
    </svg>
);

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
  const { isAuthenticated, user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    onNavigate({ page: 'home' });
  };

  return (
    <header className="bg-base-100 shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div 
            className="flex items-center gap-2 cursor-pointer text-2xl font-bold text-primary"
            onClick={() => onNavigate({ page: 'home' })}
          >
            <RecycleIcon className="w-8 h-8"/>
            <span>Đổi Đồ</span>
          </div>
          <nav className="flex items-center gap-2 md:gap-4">
            {isAuthenticated && user ? (
              <>
                <div className="hidden md:flex items-center gap-2 text-neutral bg-base-200 px-3 py-1 rounded-full">
                    <span className="font-semibold">{user.name}</span>
                    <div className="flex items-center gap-1 text-yellow-500">
                        <StarIcon />
                        <span>{user.reputation || 0}</span>
                    </div>
                </div>
                 <Notifications onNavigate={onNavigate} />
                 <Button variant="ghost" onClick={() => onNavigate({ page: 'myFavorites' })}>Yêu thích</Button>
                 <Button variant="ghost" onClick={() => onNavigate({ page: 'myItems' })}>Tin của tôi</Button>
                 <Button onClick={() => onNavigate({ page: 'addItem' })}>+ Đăng tin</Button>
                 <Button variant="secondary" onClick={handleLogout}>Đăng xuất</Button>
              </>
            ) : (
              <>
                <Button variant="ghost" onClick={() => onNavigate({ page: 'login' })}>Đăng nhập</Button>
                <Button onClick={() => onNavigate({ page: 'register' })}>Đăng ký</Button>
              </>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
