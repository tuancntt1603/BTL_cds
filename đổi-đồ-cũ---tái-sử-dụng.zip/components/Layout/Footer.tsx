
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral text-neutral-content p-4 text-center">
      <p>Bản quyền © {new Date().getFullYear()} - Đổi Đồ Cũ. Chung tay vì một hành tinh xanh.</p>
    </footer>
  );
};

export default Footer;
