
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { View } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';

interface RegisterPageProps {
  onNavigate: (view: View) => void;
}

const RegisterPage: React.FC<RegisterPageProps> = ({ onNavigate }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { register } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      await register(name, email, password);
      onNavigate({ page: 'home' });
    } catch (err: any) {
      setError(err.message || 'Đã xảy ra lỗi. Vui lòng thử lại.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto bg-base-100 p-8 rounded-xl shadow-lg">
      <h2 className="text-3xl font-bold text-center text-primary mb-6">Tạo tài khoản</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && <p className="text-red-500 bg-red-100 p-3 rounded-md">{error}</p>}
        <Input
          id="name"
          label="Tên của bạn"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          autoComplete="name"
        />
        <Input
          id="email"
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          autoComplete="email"
        />
        <Input
          id="password"
          label="Mật khẩu"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          autoComplete="new-password"
        />
        <Button type="submit" isLoading={isLoading} className="w-full">
          Đăng ký
        </Button>
      </form>
      <p className="mt-6 text-center text-sm">
        Đã có tài khoản?{' '}
        <button onClick={() => onNavigate({ page: 'login' })} className="font-medium text-primary hover:underline">
          Đăng nhập
        </button>
      </p>
    </div>
  );
};

export default RegisterPage;
