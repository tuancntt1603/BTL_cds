import React, { ButtonHTMLAttributes } from 'react';

// FIX: Add size prop to ButtonProps to allow for different button sizes. This resolves type errors in components that use the size prop.
interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
  isLoading?: boolean;
  size?: 'sm' | 'md';
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  isLoading = false,
  // FIX: Add size prop to component props destructuring, with 'md' as the default.
  size = 'md',
  className = '', 
  ...props 
}) => {
  // FIX: Padding classes are now managed by size variants, so they are removed from baseClasses.
  const baseClasses = 'rounded-lg font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 flex items-center justify-center gap-2';
  
  const variantClasses = {
    primary: 'bg-primary text-primary-content hover:bg-primary-focus focus:ring-primary',
    secondary: 'bg-secondary text-white hover:bg-secondary-focus focus:ring-secondary',
    ghost: 'bg-transparent text-neutral hover:bg-base-300 focus:ring-primary',
  };
  
  // FIX: Add size-specific classes for padding and font size.
  const sizeClasses = {
    sm: 'px-3 py-1 text-sm',
    md: 'px-4 py-2',
  };

  const disabledClasses = 'disabled:bg-gray-300 disabled:cursor-not-allowed disabled:text-gray-500';

  return (
    <button
      // FIX: Dynamically apply the appropriate size class based on the size prop.
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${disabledClasses} ${className}`}
      disabled={isLoading || props.disabled}
      {...props}
    >
      {isLoading && (
        <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      )}
      {children}
    </button>
  );
};

export default Button;
