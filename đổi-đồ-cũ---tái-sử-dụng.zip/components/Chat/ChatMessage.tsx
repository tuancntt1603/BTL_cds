
import React from 'react';
import { ChatMessage as ChatMessageType } from '../../types';

interface ChatMessageProps {
  message: ChatMessageType;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.sender === 'user';

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      <div
        className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl text-sm break-words ${
          isUser
            ? 'bg-primary text-primary-content rounded-br-none'
            : 'bg-base-300 text-gray-800 rounded-bl-none'
        }`}
      >
        {message.sender === 'ai' ? (
           <div className="ai-message" dangerouslySetInnerHTML={{ __html: message.text }} />
        ) : (
          <p>{message.text}</p>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;
