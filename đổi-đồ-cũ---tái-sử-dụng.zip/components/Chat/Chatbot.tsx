
import React, { useState, useRef, useEffect } from 'react';
import { View, ChatMessage as ChatMessageType } from '../../types';
import * as itemService from '../../services/itemService';
import * as geminiService from '../../services/geminiService';
import ChatMessage from './ChatMessage';
import Button from '../ui/Button';

interface ChatbotProps {
  onNavigate: (view: View) => void;
  currentView: View;
}

const AiIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m12.728 0l.707-.707M6.343 17.657l-.707.707m12.728 0l.707.707M12 21v-1m-4-4H5a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2zM19 13h-2a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2z" />
    </svg>
);

const CloseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const Chatbot: React.FC<ChatbotProps> = ({ onNavigate, currentView }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessageType[]>([
    { sender: 'ai', text: '<p>Chào bạn! 👋 Đang tìm đồ cũ? Hãy hỏi mình thử xem, ví dụ như "tìm ghế sofa" hoặc "đồ cho bé" nhé!</p>' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    // Tự động mở chat trên trang chủ, chỉ một lần mỗi session
    const hasBeenShown = sessionStorage.getItem('proactiveChatShown');
    if (currentView.page === 'home' && !hasBeenShown && !isOpen) {
      const timer = setTimeout(() => {
        setIsOpen(true);
        sessionStorage.setItem('proactiveChatShown', 'true');
      }, 3000); // Trễ 3 giây

      return () => clearTimeout(timer); // Dọn dẹp timer
    }
  }, [currentView, isOpen]);
  
  const parseAIResponse = (text: string): string => {
    const lines = text.split('\n');
    let html = '';
    let inList = false;

    for (const line of lines) {
        const trimmedLine = line.trim();
        if (trimmedLine === '') continue;

        const match = trimmedLine.match(/-\s\[(item_[\w\d]+)\]\s(.+)/);
        
        if (match) {
            if (!inList) {
                html += '<ul class="list-disc pl-5 space-y-1 mt-2">';
                inList = true;
            }
            const itemId = match[1];
            const itemTitle = match[2];
            html += `<li><a href="#" data-item-id="${itemId}" class="text-secondary font-semibold hover:underline">${itemTitle}</a></li>`;
        } else if (trimmedLine.startsWith('-')) {
             if (!inList) {
                html += '<ul class="list-disc pl-5 space-y-1 mt-2">';
                inList = true;
            }
            html += `<li>${trimmedLine.substring(1).trim()}</li>`;
        } else {
            if (inList) {
                html += '</ul>';
                inList = false;
            }
            html += `<p class="mb-2">${trimmedLine}</p>`;
        }
    }

    if (inList) {
        html += '</ul>';
    }
    
    // Clean up to remove last paragraph's margin
    if (html.endsWith('</p>')) {
        const lastPIndex = html.lastIndexOf('<p class="mb-2">');
        if (lastPIndex !== -1) {
             const endPart = html.substring(lastPIndex + 16);
             if (!endPart.includes('<p')) {
                 html = html.substring(0, lastPIndex) + `<p>${endPart.replace('</p>','')}</p>`;
             }
        }
    }
    
    return html;
  };
  
   const handleChatClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    if (target.tagName === 'A' && target.dataset.itemId) {
        e.preventDefault();
        onNavigate({ page: 'itemDetail', itemId: target.dataset.itemId });
        setIsOpen(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessageType = { sender: 'user', text: inputValue };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const allItems = await itemService.getItems();
      const aiResponseText = await geminiService.chatWithAI(userMessage.text, allItems);
      const parsedHtml = parseAIResponse(aiResponseText);
      const aiMessage: ChatMessageType = { sender: 'ai', text: parsedHtml };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error: any) {
      const errorMessage: ChatMessageType = { sender: 'ai', text: `<p>${error.message || 'Xin lỗi, đã có lỗi xảy ra.'}</p>` };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <div className={`fixed bottom-4 right-4 z-[9998] transition-transform duration-300 ${isOpen ? 'scale-0' : 'scale-100'}`}>
        <Button variant="primary" onClick={() => setIsOpen(true)} className="rounded-full w-16 h-16 shadow-lg">
          <AiIcon />
        </Button>
      </div>

      <div className={`fixed bottom-0 right-0 sm:bottom-4 sm:right-4 z-[9999] w-full h-full sm:w-[400px] sm:h-[600px] bg-base-100 shadow-2xl rounded-lg flex flex-col transition-transform duration-300 origin-bottom-right ${isOpen ? 'scale-100' : 'scale-0'}`}>
        {/* Header */}
        <div className="flex justify-between items-center p-4 bg-base-200 border-b">
          <h3 className="font-bold text-lg text-neutral">Trợ lý AI</h3>
          <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-gray-800">
            <CloseIcon />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-grow p-4 overflow-y-auto" onClick={handleChatClick}>
          {messages.map((msg, index) => (
            <ChatMessage key={index} message={msg} />
          ))}
          {isLoading && (
            <div className="flex justify-start mb-4">
                 <div className="max-w-xs px-4 py-3 rounded-2xl bg-base-300 text-gray-800 rounded-bl-none">
                    <div className="flex items-center gap-2">
                        <span className="h-2 w-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                        <span className="h-2 w-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                        <span className="h-2 w-2 bg-gray-500 rounded-full animate-bounce"></span>
                    </div>
                 </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 bg-base-200 border-t">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Nhập tin nhắn..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
              disabled={isLoading}
            />
            <Button type="submit" isLoading={isLoading} disabled={!inputValue.trim()}>Gửi</Button>
          </form>
        </div>
      </div>
    </>
  );
};

export default Chatbot;